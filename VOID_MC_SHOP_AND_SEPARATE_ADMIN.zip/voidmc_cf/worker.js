const RANKS = { BOOSTER: 49, SEAMAN: 79, CAPTAIN: 129, ROYAL: 179, MONARCH: 229 };
const DISCORD = 'https://discord.gg/VQvDh3bnmA';
const COOKIE = 'vm_admin';
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

const json = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), {
  status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers }
});
const clean = (v, max = 120) => String(v ?? '').trim().slice(0, max);
const now = () => new Date().toISOString();
const randomHex = (bytes = 16) => [...crypto.getRandomValues(new Uint8Array(bytes))].map(x => x.toString(16).padStart(2, '0')).join('').toUpperCase();
function randomCode() {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return 'VM' + [...bytes].map(b => ALPHABET[b % ALPHABET.length]).join('') + 'HE';
}
async function hmac(value, secret) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value));
  return [...new Uint8Array(sig)].map(x => x.toString(16).padStart(2, '0')).join('');
}
function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let out = 0; for (let i = 0; i < a.length; i++) out |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return out === 0;
}
async function adminCookie(token, env) {
  const expires = Math.floor(Date.now() / 1000) + 8 * 60 * 60;
  const payload = `${token}.${expires}`;
  const sig = await hmac(payload, env.SESSION_SECRET);
  return `${COOKIE}=${payload}.${sig}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800`;
}
async function isAdmin(request, env) {
  const raw = (request.headers.get('Cookie') || '').split(';').map(x => x.trim()).find(x => x.startsWith(COOKIE + '='))?.slice(COOKIE.length + 1);
  if (!raw) return false;
  const [token, exp, sig] = raw.split('.');
  if (!token || !exp || !sig || !/^\d+$/.test(exp) || Number(exp) < Math.floor(Date.now() / 1000)) return false;
  const expected = await hmac(`${token}.${exp}`, env.SESSION_SECRET);
  return safeEqual(sig, expected);
}
function promptFor(order) {
  return `VOID MC | OFFICIAL RANK STORE\nOrder: ${order.id}\nCustomer: ${order.customer_name}\nMinecraft username: ${order.minecraft_username || ''}\nLocation: ${order.location}\nPhone: ${order.phone}\nEmail: ${order.email}\nItems: ${order.items.map(x => `${x.name} x${x.qty}`).join(', ')}\nSubtotal: ₹${order.subtotal}\nDiscount: ₹${order.discount}\nTotal to pay: ₹${order.total}\nCoupon: ${order.coupon || 'None'}\nPayment: Please pay using the QR shown on the official store, then submit this prompt in a Buy Item ticket on Discord.\nDiscord: ${DISCORD}`;
}
async function bodyJson(request) {
  try { return await request.json(); } catch { return {}; }
}
async function adminGuard(request, env) {
  if (!await isAdmin(request, env)) return json({ error: 'Admin login required' }, 401);
  return null;
}

// ---- Maintenance Mode: stored in the shared `settings` table, read live on every request (no redeploy needed).
const MAINT_DEFAULT_MSG = 'We are performing scheduled maintenance to improve VOID MC SHOP. Please check back soon.';
async function maintenanceState(DB) {
  const { results = [] } = await DB.prepare("SELECT key,value FROM settings WHERE key IN ('maintenance_enabled','maintenance_message','maintenance_updated_at')").all();
  const m = Object.fromEntries(results.map(r => [r.key, r.value]));
  return { enabled: m.maintenance_enabled === '1', message: clean(m.maintenance_message, 500) || MAINT_DEFAULT_MSG, updatedAt: m.maintenance_updated_at || '' };
}
const maintenanceBlocked = m => json({ error: 'The shop is under maintenance. Please try again later.', maintenance: true, message: m.message }, 503);

// ---- Free Rank: settings live in the shared `settings` table (edited from the admin dashboard).
const FREE_DEFAULTS = { free_rank_name: 'SEAMAN', free_rank_price: '79', free_rank_max: '3', free_rank_description: 'Make waves across the server.', free_rank_enabled: '1' };
async function freeRankState(DB) {
  const { results = [] } = await DB.prepare("SELECT key,value FROM settings WHERE key IN ('free_rank_name','free_rank_price','free_rank_max','free_rank_description','free_rank_enabled')").all();
  const m = { ...FREE_DEFAULTS, ...Object.fromEntries(results.map(r => [r.key, r.value])) };
  const claimed = Number((await DB.prepare("SELECT COUNT(*) AS n FROM free_rank_claims WHERE status='active'").first()).n || 0);
  const maxN = Number(m.free_rank_max), max = Number.isInteger(maxN) && maxN >= 0 ? maxN : 3, priceN = Number(m.free_rank_price);
  const remaining = Math.max(0, max - claimed), enabled = m.free_rank_enabled === '1';
  return { name: m.free_rank_name, price: Number.isInteger(priceN) && priceN >= 0 ? priceN : 0, description: m.free_rank_description, max, enabled, claimed, remaining, available: enabled && remaining > 0 };
}
// Self-heal: databases created earlier (e.g. by the admin Worker) may lack tables/columns this Worker needs.
// Everything here is idempotent and only runs once per Worker instance.
const HEAL_SQL = [
  "CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)",
  "CREATE TABLE IF NOT EXISTS announcements (id TEXT PRIMARY KEY, message TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)",
  "CREATE TABLE IF NOT EXISTS free_rank_claims (id TEXT PRIMARY KEY, customer_name TEXT NOT NULL, minecraft_username TEXT NOT NULL, location TEXT NOT NULL, phone TEXT NOT NULL, email TEXT NOT NULL, rank_name TEXT NOT NULL DEFAULT 'SEAMAN', created_at TEXT NOT NULL)",
  "INSERT OR IGNORE INTO settings (key,value) VALUES ('maintenance_enabled','0'),('maintenance_message','"+MAINT_DEFAULT_MSG+"'),('maintenance_updated_at','')",
  "INSERT OR IGNORE INTO settings (key,value) VALUES ('free_rank_name','SEAMAN'),('free_rank_price','79'),('free_rank_max','3'),('free_rank_description','Make waves across the server.'),('free_rank_enabled','1')",
  "INSERT OR IGNORE INTO settings (key,value) VALUES ('music_enabled','0'),('music_key',''),('music_name',''),('music_type',''),('music_size','0'),('music_version',''),('music_updated_at','')"
];
let schemaReady;
const ensureSchema = env => schemaReady ||= (async () => {
  for (const q of HEAL_SQL) { try { await env.DB.prepare(q).run(); } catch (e) { console.error('heal step failed', q.slice(0, 40), e); } }
  try {
    const cols = (await env.DB.prepare('PRAGMA table_info(ranks)').all()).results || [];
    if (cols.length && !cols.some(c => c.name === 'category')) await env.DB.prepare("ALTER TABLE ranks ADD COLUMN category TEXT NOT NULL DEFAULT 'Ranks'").run();
    const claimCols=(await env.DB.prepare('PRAGMA table_info(free_rank_claims)').all()).results||[];if(claimCols.length&&!claimCols.some(c=>c.name==='status'))await env.DB.prepare("ALTER TABLE free_rank_claims ADD COLUMN status TEXT NOT NULL DEFAULT 'active'").run();
  } catch (e) { console.error('heal ranks.category failed', e); }
})().catch(e => { schemaReady = null; throw e; });
// ---- Background music: flags live in the shared `settings` table, the audio file in the shared R2 bucket (MEDIA).
// Only the admin Worker can change them; this Worker only reads them and streams the file to visitors.
async function musicState(DB) {
  const { results = [] } = await DB.prepare("SELECT key,value FROM settings WHERE key IN ('music_enabled','music_key','music_type','music_version')").all();
  const m = Object.fromEntries(results.map(r => [r.key, r.value]));
  return { active: m.music_enabled === '1' && !!m.music_key, key: m.music_key || '', type: m.music_type || 'audio/mpeg', version: m.music_version || '' };
}
function contentRange(r, size) {
  if (!r) return null;
  let start, end;
  if (r.suffix !== undefined) { start = Math.max(0, size - r.suffix); end = size - 1; }
  else { start = r.offset ?? 0; end = r.length !== undefined ? Math.min(size - 1, start + r.length - 1) : size - 1; }
  return `bytes ${start}-${end}/${size}`;
}
// Streams the music with HTTP Range support (iOS Safari will not play audio from a server that ignores Range).
async function serveMusic(request, env, url) {
  if (request.method !== 'GET' && request.method !== 'HEAD') return new Response('Method not allowed', { status: 405, headers: { allow: 'GET, HEAD' } });
  if (!env.MEDIA || !env.DB) return new Response('Music storage is not configured', { status: 503 });
  try {
    const m = await musicState(env.DB);
    if (!m.active) return new Response('Not found', { status: 404, headers: { 'cache-control': 'no-store' } });
    const h = new Headers({ 'content-type': m.type, 'accept-ranges': 'bytes', 'x-content-type-options': 'nosniff', 'cross-origin-resource-policy': 'same-origin',
      // The URL carries ?v=<version>, so a cached copy can never be stale: a new upload changes the version and therefore the URL.
      'cache-control': url.searchParams.get('v') === m.version ? 'public, max-age=31536000, immutable' : 'public, max-age=300' });
    if (request.method === 'HEAD') {
      const head = await env.MEDIA.head(m.key);
      if (!head) return new Response('Not found', { status: 404 });
      h.set('content-length', String(head.size)); h.set('etag', head.httpEtag);
      return new Response(null, { status: 200, headers: h });
    }
    let obj;
    try { obj = await env.MEDIA.get(m.key, { range: request.headers, onlyIf: request.headers }); }
    catch (e) { if (/range/i.test(String(e && e.message))) return new Response('Range not satisfiable', { status: 416 }); throw e; }
    if (!obj) return new Response('Not found', { status: 404 });
    h.set('etag', obj.httpEtag);
    const cr = contentRange(obj.range, obj.size);
    if (cr) h.set('content-range', cr);
    return new Response(obj.body || null, { status: !obj.body ? 304 : cr ? 206 : 200, headers: h });
  } catch (e) { console.error('music unavailable', e); return new Response('Music unavailable', { status: 404 }); }
}
async function api(request, env) {
  const url = new URL(request.url), path = url.pathname, method = request.method;
  if (!env.DB || !env.ADMIN_PASSWORD || !env.SESSION_SECRET) return json({ error: 'Store backend is not configured. Check D1 binding and Worker secrets.' }, 500);
  try { await ensureSchema(env); } catch (e) { console.error('ensureSchema failed', e); }
  if (path === '/api/announcement' && method === 'GET') {
    const a=await env.DB.prepare('SELECT message FROM announcements WHERE active=1 ORDER BY updated_at DESC LIMIT 1').first();return json({text:a?.message||''});
  }

  if (path === '/api/music' && method === 'GET') {
    const m = await musicState(env.DB);
    return json(m.active && env.MEDIA ? { enabled: true, version: m.version, url: '/media/music?v=' + encodeURIComponent(m.version) } : { enabled: false });
  }

  if (path === '/api/maintenance' && method === 'GET') { const m = await maintenanceState(env.DB); return json({ enabled: m.enabled, message: m.enabled ? m.message : '' }); }

  if (path === '/api/free-rank' && method === 'GET') return json(await freeRankState(env.DB));
  if (path === '/api/free-rank/claim' && method === 'POST') {
    const d = await bodyJson(request), name = clean(d.name,80), username = clean(d.username,16), location = clean(d.location,120), phone = clean(d.phone,24), email = clean(d.email,120);
    if (!name || !/^[A-Za-z0-9_]{3,16}$/.test(username) || !location || !/^[+\d\s()-]{7,24}$/.test(phone) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({error:'Enter valid customer details and Minecraft username.'},400);
    const maint = await maintenanceState(env.DB); if (maint.enabled) return maintenanceBlocked(maint);
    const before = await freeRankState(env.DB);
    if (!before.enabled) return json({error:'The free rank is not available right now.'},403);
    const id = 'FREE-' + randomHex(6);
    // One atomic statement: enabled flag, current max and rank name are all read inside the INSERT, so concurrent claims can never exceed the limit.
    const result = await env.DB.prepare(`INSERT INTO free_rank_claims (id,customer_name,minecraft_username,location,phone,email,rank_name,created_at)
      SELECT ?,?,?,?,?,?,COALESCE((SELECT value FROM settings WHERE key='free_rank_name'),'SEAMAN'),?
      WHERE COALESCE((SELECT value FROM settings WHERE key='free_rank_enabled'),'1')='1'
        AND COALESCE((SELECT value FROM settings WHERE key='maintenance_enabled'),'0')<>'1'
        AND NOT EXISTS (SELECT 1 FROM free_rank_claims WHERE status='active' AND lower(minecraft_username)=lower(?))
        AND NOT EXISTS (SELECT 1 FROM free_rank_claims WHERE status='active' AND lower(email)=lower(?))
        AND (SELECT COUNT(*) FROM free_rank_claims WHERE status='active') < COALESCE((SELECT CAST(value AS INTEGER) FROM settings WHERE key='free_rank_max' AND value GLOB '[0-9]*'),3)`).bind(id,name,username,location,phone,email,now(),username,email).run();
    const after = await freeRankState(env.DB);
    if (!result.meta.changes) { const m2 = await maintenanceState(env.DB); if (m2.enabled) return maintenanceBlocked(m2); const duplicate=await env.DB.prepare("SELECT 1 FROM free_rank_claims WHERE status='active' AND (lower(minecraft_username)=lower(?) OR lower(email)=lower(?)) LIMIT 1").bind(username,email).first(); return json({error: duplicate?'This Minecraft username or email has already claimed the Free Rank.':after.enabled ? `All ${after.max} free ${after.name} claims have already been taken.` : 'The free rank is not available right now.'},409); }
    return json({ok:true,rank:after.name,claimNumber:after.claimed,remaining:after.remaining});
  }
  if (path === '/api/config' && method === 'GET') {
    let results=[];
    try { results=(await env.DB.prepare('SELECT name,price,tier,description,icon,category FROM ranks WHERE active=1 ORDER BY category,sort,name').all()).results||[]; }
    catch (e) { console.error('config: category column missing, using fallback', e); results=((await env.DB.prepare("SELECT name,price,tier,description,icon,'Ranks' AS category FROM ranks WHERE active=1 ORDER BY sort,name").all()).results||[]); }
    let setting=null; try { setting=await env.DB.prepare("SELECT value FROM settings WHERE key='upi_id'").first(); } catch (e) { console.error('config: settings unavailable', e); }
    const publicSettings = (await env.DB.prepare("SELECT key,value FROM settings WHERE key IN ('logo_key','background_key')").all()).results || [];
    const ps = Object.fromEntries(publicSettings.map(x=>[x.key,x.value]));
    const ann=(await env.DB.prepare('SELECT message FROM announcements WHERE active=1 ORDER BY updated_at DESC LIMIT 1').first());
    const maintenance = await maintenanceState(env.DB);
    return json({maintenance:{enabled:maintenance.enabled,message:maintenance.enabled?maintenance.message:''},ranks:results,upiId:clean(setting?.value || env.UPI_ID,100),announcement:ann?.message||'',logoUrl:ps.logo_key?'/media/logo':'',backgroundUrl:ps.background_key?'/media/background':''});
  }

  if (path === '/api/coupons/validate' && method === 'POST') {
    const data = await bodyJson(request), code = clean(data.code, 6).toUpperCase();
    const row = await env.DB.prepare('SELECT discount FROM coupons WHERE code = ? AND active = 1').bind(code).first();
    if (!row) return json({ error: 'Invalid or inactive coupon' }, 404);
    return json({ discount: row.discount });
  }

  if (path === '/api/orders' && method === 'POST') {
    const maint = await maintenanceState(env.DB); if (maint.enabled) return maintenanceBlocked(maint);
    const data = await bodyJson(request);
    const name = clean(data.name, 80), location = clean(data.location, 120), phone = clean(data.phone, 24), username = clean(data.username,16), email = clean(data.email, 120);
    if (!name || !/^[A-Za-z0-9_]{3,16}$/.test(username) || !location || !/^[+\d\s()-]{7,24}$/.test(phone) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: 'Enter a name, location, valid phone number and email address.' }, 400);
    const raw = Array.isArray(data.items) ? data.items : [], items = [];
    for (const item of raw) {
      const rank = clean(item.name, 20).toUpperCase(), qty = Number(item.qty);
      if (!Number.isInteger(qty) || qty < 1 || qty > 10) return json({ error: 'Invalid cart item.' }, 400);
      const rankRow = await env.DB.prepare('SELECT price FROM ranks WHERE name=? AND active=1').bind(rank).first(); if (!rankRow) return json({error:'This rank is unavailable.'},400); const found = items.find(x => x.name === rank);
      if (found) found.qty += qty; else items.push({ name: rank, qty, price: rankRow.price });
    }
    if (!items.length || items.some(x => x.qty > 10)) return json({ error: 'Your cart is empty or has too many items.' }, 400);
    const subtotal = items.reduce((sum, x) => sum + Number(x.price) * x.qty, 0);
    let coupon = '', discount = 0;
    if (data.coupon) {
      coupon = clean(data.coupon, 6).toUpperCase();
      const row = await env.DB.prepare('SELECT discount FROM coupons WHERE code = ? AND active = 1').bind(coupon).first();
      if (!row) return json({ error: 'Coupon is invalid or inactive.' }, 400);
      discount = Math.floor(subtotal * row.discount / 100);
    }
    const id = 'VM-' + randomHex(5), total = subtotal - discount;
    const order = { id, customer_name: name, location, phone, minecraft_username: username, email, items, subtotal, discount, total, coupon };
    const prompt = promptFor(order);
    // Atomic: the maintenance flag is re-checked inside the INSERT, so an order can never slip in after maintenance is switched ON.
    const ins = await env.DB.prepare(`INSERT INTO orders (id,customer_name,location,phone,minecraft_username,email,items,subtotal,discount,total,coupon,prompt,created_at)
      SELECT ?,?,?,?,?,?,?,?,?,?,?,?,? WHERE COALESCE((SELECT value FROM settings WHERE key='maintenance_enabled'),'0')<>'1'`).bind(id, name, location, phone, username, email, JSON.stringify(items), subtotal, discount, total, coupon, prompt, now()).run();
    if (!ins.meta.changes) return maintenanceBlocked(await maintenanceState(env.DB));
    return json({ orderId: id, prompt, total });
  }

  const paidMatch = path.match(/^\/api\/orders\/([A-Za-z0-9-]+)\/paid$/);
  if (paidMatch && method === 'POST') {
    const id = clean(paidMatch[1], 40);
    const order = await env.DB.prepare('SELECT id,code,status FROM orders WHERE id = ?').bind(id).first();
    if (!order) return json({ error: 'Order not found' }, 404);
    if (order.code) return json({ verificationCode: order.code });
    let code;
    for (let i = 0; i < 8; i++) {
      code = randomCode();
      try {
        await env.DB.prepare("UPDATE orders SET code = ?, status = 'payment_submitted' WHERE id = ? AND code IS NULL").bind(code, id).run();
        const latest = await env.DB.prepare('SELECT code FROM orders WHERE id = ?').bind(id).first();
        if (latest?.code) return json({ verificationCode: latest.code });
      } catch (e) { if (i === 7) throw e; }
    }
    return json({ error: 'Could not create a verification code. Please contact support.' }, 500);
  }

  if (path === '/api/admin/login' && method === 'POST') {
    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    const ipKey = await hmac(ip, env.SESSION_SECRET);
    const timestamp = Date.now();
    const attempt = await env.DB.prepare('SELECT attempts, window_start, blocked_until FROM login_attempts WHERE ip_key = ?').bind(ipKey).first();
    if (attempt?.blocked_until && attempt.blocked_until > timestamp) return json({ error: 'Too many login attempts. Try again in 15 minutes.' }, 429);
    if (!attempt || timestamp - attempt.window_start > 15 * 60 * 1000) {
      await env.DB.prepare('INSERT INTO login_attempts (ip_key,attempts,window_start,blocked_until) VALUES (?,0,?,0) ON CONFLICT(ip_key) DO UPDATE SET attempts=0,window_start=excluded.window_start,blocked_until=0').bind(ipKey, timestamp).run();
    }
    const data = await bodyJson(request), candidate = String(data.password || '');
    if (!safeEqual(candidate, String(env.ADMIN_PASSWORD))) {
      const updated = await env.DB.prepare('UPDATE login_attempts SET attempts=attempts+1 WHERE ip_key=? RETURNING attempts').bind(ipKey).first();
      if (updated?.attempts >= 8) await env.DB.prepare('UPDATE login_attempts SET blocked_until=? WHERE ip_key=?').bind(timestamp + 15 * 60 * 1000, ipKey).run();
      return json({ error: 'Invalid credentials' }, 401);
    }
    await env.DB.prepare('DELETE FROM login_attempts WHERE ip_key=?').bind(ipKey).run();
    const token = randomHex(32);
    return json({ ok: true }, 200, { 'set-cookie': await adminCookie(token, env) });
  }

  if (path.startsWith('/api/admin/')) {
    const denied = await adminGuard(request, env); if (denied) return denied;
  }
  if (path === '/api/admin/logout' && method === 'POST') return json({ ok: true }, 200, { 'set-cookie': `${COOKIE}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0` });
  if (path === '/api/admin/orders' && method === 'GET') {
    const { results = [] } = await env.DB.prepare('SELECT id,customer_name,location,phone,minecraft_username,email,items,subtotal,discount,total,coupon,code,status,created_at FROM orders ORDER BY created_at DESC LIMIT 250').all();
    return json(results.map(x => ({ ...x, items: JSON.parse(x.items) })));
  }
  if (path === '/api/admin/verify' && method === 'POST') {
    const data = await bodyJson(request), code = clean(data.code, 20).toUpperCase();
    if (!/^VM[A-Z2-9]{16}HE$/.test(code)) return json({ valid: false, status: 'invalid' });
    const row = await env.DB.prepare('SELECT id,customer_name,minecraft_username,total,status,created_at FROM orders WHERE code = ?').bind(code).first();
    return json(row ? { valid: true, ...row } : { valid: false, status: 'invalid' });
  }
  const statusMatch = path.match(/^\/api\/admin\/orders\/([A-Za-z0-9-]+)\/status$/);
  if (statusMatch && method === 'POST') {
    const data = await bodyJson(request), status = clean(data.status, 20);
    if (!['verified', 'rejected'].includes(status)) return json({ error: 'Invalid status' }, 400);
    const result = await env.DB.prepare('UPDATE orders SET status = ? WHERE id = ? AND code IS NOT NULL').bind(status, clean(statusMatch[1], 40)).run();
    if (!result.meta.changes) return json({ error: 'Coded order not found' }, 404);
    return json({ ok: true });
  }
  if (path === '/api/admin/maintenance' && method === 'GET') return json(await maintenanceState(env.DB));
  if (path === '/api/admin/maintenance' && method === 'PUT') {
    const d = await bodyJson(request), cur = await maintenanceState(env.DB);
    if (d.enabled !== undefined && typeof d.enabled !== 'boolean') return json({error:'Enabled must be true or false.'},400);
    if (d.message !== undefined && typeof d.message !== 'string') return json({error:'Message must be text.'},400);
    const message = d.message === undefined ? cur.message : clean(d.message, 500);
    if (!message) return json({error:'Enter a maintenance reason/message.'},400);
    const enabled = d.enabled === undefined ? cur.enabled : d.enabled;
    await env.DB.batch([['maintenance_enabled',enabled?'1':'0'],['maintenance_message',message],['maintenance_updated_at',now()]]
      .map(([k,v])=>env.DB.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(k,v)));
    return json({ok:true,...(await maintenanceState(env.DB))});
  }
  if (path === '/api/admin/free-claims' && method === 'GET') {
    const {results=[]}=await env.DB.prepare('SELECT * FROM free_rank_claims ORDER BY created_at ASC').all(); return json(results);
  }
  if (path === '/api/admin/free-rank' && method === 'GET') {
    const {results=[]}=await env.DB.prepare('SELECT id,customer_name,minecraft_username,location,phone,email,rank_name,created_at FROM free_rank_claims ORDER BY created_at ASC').all();
    return json({ ...(await freeRankState(env.DB)), claims: results });
  }
  if (path === '/api/admin/free-rank' && method === 'PUT') {
    const d = await bodyJson(request), name = clean(d.name,24), description = clean(d.description,120), price = Number(d.price), max = Number(d.max);
    if (!/^[A-Za-z0-9 _-]{2,24}$/.test(name)) return json({error:'Rank name: 2–24 letters, numbers, spaces, - or _.'},400);
    if (!Number.isInteger(price) || price < 0 || price > 100000) return json({error:'Price must be a whole number of rupees, 0–100000.'},400);
    if (!Number.isInteger(max) || max < 0 || max > 1000) return json({error:'Maximum claims must be a whole number, 0–1000.'},400);
    if (typeof d.enabled !== 'boolean') return json({error:'Enabled must be ON or OFF.'},400);
    await env.DB.batch([['free_rank_name',name],['free_rank_price',String(price)],['free_rank_max',String(max)],['free_rank_description',description],['free_rank_enabled',d.enabled?'1':'0']]
      .map(([k,v])=>env.DB.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(k,v)));
    return json({ok:true,...(await freeRankState(env.DB))});
  }
  const freeClaim = path.match(/^\/api\/admin\/free-claims\/([A-Za-z0-9-]+)$/);
  if (freeClaim && method === 'DELETE') { const r=await env.DB.prepare('DELETE FROM free_rank_claims WHERE id=?').bind(clean(freeClaim[1],40)).run(); return r.meta.changes?json({ok:true}):json({error:'Claim not found'},404); }
  const deleteOrder = path.match(/^\/api\/admin\/orders\/([A-Za-z0-9-]+)$/);
  if (deleteOrder && method === 'DELETE') { const r=await env.DB.prepare('DELETE FROM orders WHERE id=?').bind(clean(deleteOrder[1],40)).run(); return r.meta.changes?json({ok:true}):json({error:'Order not found'},404); }
  if (path === '/api/admin/coupons' && method === 'GET') {
    const { results = [] } = await env.DB.prepare('SELECT code,discount,active,created_at FROM coupons ORDER BY created_at DESC').all();
    return json(results);
  }
  if (path === '/api/admin/coupons' && method === 'POST') {
    const data = await bodyJson(request), code = clean(data.code, 6).toUpperCase(), discount = Number(data.discount);
    if (!/^[A-Z0-9]{6}$/.test(code) || !Number.isInteger(discount) || discount < 1 || discount > 90) return json({ error: 'Coupon must be 6 letters/numbers; discount must be 1–90%.' }, 400);
    try { await env.DB.prepare('INSERT INTO coupons (code,discount,created_at) VALUES (?,?,?)').bind(code, discount, now()).run(); }
    catch { return json({ error: 'That coupon already exists.' }, 409); }
    return json({ ok: true, code, discount });
  }
  if (path === '/api/admin/coupons/random' && method === 'POST') {
    const data = await bodyJson(request), discount = Number(data.discount);
    if (!Number.isInteger(discount) || discount < 1 || discount > 90) return json({ error: 'Discount must be 1–90%.' }, 400);
    for (let i = 0; i < 20; i++) {
      const code = [...crypto.getRandomValues(new Uint8Array(6))].map(b => ALPHABET[b % ALPHABET.length]).join('');
      try { await env.DB.prepare('INSERT INTO coupons (code,discount,created_at) VALUES (?,?,?)').bind(code, discount, now()).run(); return json({ ok: true, code, discount }); } catch {}
    }
    return json({ error: 'Could not generate a unique coupon.' }, 500);
  }
  const couponMatch = path.match(/^\/api\/admin\/coupons\/([A-Za-z0-9]{6})$/);
  if (couponMatch && method === 'PATCH') {
    const data = await bodyJson(request), active = data.active ? 1 : 0;
    const result = await env.DB.prepare('UPDATE coupons SET active = ? WHERE code = ?').bind(active, couponMatch[1].toUpperCase()).run();
    if (!result.meta.changes) return json({ error: 'Coupon not found' }, 404);
    return json({ ok: true });
  }
  if (couponMatch && method === 'DELETE') {
    await env.DB.prepare('DELETE FROM coupons WHERE code = ?').bind(couponMatch[1].toUpperCase()).run();
    return json({ ok: true });
  }
  return json({ error: 'Not found' }, 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/media/music') return serveMusic(request, env, url);
    if (url.pathname === '/media/logo' || url.pathname === '/media/background') {
      if (!env.MEDIA) return new Response('Media storage is not configured', {status:503});
      try { const key = url.pathname.endsWith('/logo') ? await env.DB.prepare("SELECT value FROM settings WHERE key='logo_key'").first() : await env.DB.prepare("SELECT value FROM settings WHERE key='background_key'").first(); if(!key?.value)return new Response('Not found',{status:404}); const obj=await env.MEDIA.get(key.value); if(!obj)return new Response('Not found',{status:404}); const h=new Headers();obj.writeHttpMetadata(h);h.set('cache-control','public, max-age=300');return new Response(obj.body,{headers:h}); } catch(e){return new Response('Media unavailable',{status:404});}
    }
    if (url.pathname.startsWith('/api/')) {
      if (!['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'].includes(request.method)) return json({ error: 'Method not allowed' }, 405);
      if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: { 'access-control-allow-origin': url.origin, 'access-control-allow-credentials': 'true', 'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS', 'access-control-allow-headers': 'Content-Type' } });
      try { return await api(request, env); }
      catch (error) { console.error('VOID MC API error:', error); return json({ error: 'Server error. Please try again.' }, 500); }
    }
    const host = url.hostname.toLowerCase();
    const isAdminHost = host === 'admin.voidmc.bond';
    if (isAdminHost) {
      // The admin dashboard is served only on its dedicated hostname.
      if (url.pathname === '/' || url.pathname === '/index.html') {
        const adminUrl = new URL('/admin.html', url);
        return env.ASSETS.fetch(new Request(adminUrl, request));
      }
      return env.ASSETS.fetch(request);
    }
    if (url.pathname === '/admin.html' || url.pathname === '/admin.js' || url.pathname === '/admin.css') {
      return Response.redirect('https://admin.voidmc.bond/', 302);
    }
    return env.ASSETS.fetch(request);
  }
};

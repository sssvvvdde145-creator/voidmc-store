# VOID MC Official Store — Cloudflare Workers + D1

This is the Cloudflare-native conversion of the VOID MC store. Static files are served from `public/`; API routes run in `worker.js`; orders and coupons are stored in Cloudflare D1.

## Before you deploy
- A Cloudflare account and a domain already added to Cloudflare.
- Node.js 20+ and npm installed on your computer.
- Never publish your admin password or session secret. Set them as Worker secrets.

## Step-by-step deployment

1. Extract this ZIP on your computer.
2. Open a terminal in the extracted `VOID_MC_Cloudflare` folder and run:
   ```bash
   npm install
   npx wrangler login
   ```
3. Create the D1 database:
   ```bash
   npx wrangler d1 create void-mc-store-db
   ```
   Copy the `database_id` printed by Cloudflare. Open `wrangler.jsonc` and replace `PASTE_YOUR_D1_DATABASE_ID_HERE` with that ID. Keep the database name exactly `void-mc-store-db`.
4. Create the database tables:
   ```bash
   npx wrangler d1 migrations apply void-mc-store-db --remote
   ```
5. Set the private admin password and session signing secret:
   ```bash
   npx wrangler secret put ADMIN_PASSWORD
   npx wrangler secret put SESSION_SECRET
   ```
   Enter each value when prompted. Choose a new, unique admin password (preferably 16+ characters). For SESSION_SECRET, use a different random string with at least 32 characters. Do not put either value in `public/`, HTML, or JavaScript.
6. Optional UPI ID (if you want it displayed):
   ```bash
   npx wrangler secret put UPI_ID
   ```
   Enter your UPI ID. If omitted, the site will show the QR payment instruction only.
7. Deploy:
   ```bash
   npm run deploy
   ```
   Cloudflare prints a `workers.dev` URL. Open it and test a sample cart/order, coupon validation, payment-submission code, and admin login.

## Connect `shop.voidmc.bond`

1. In Cloudflare Dashboard, open **Workers & Pages** → `void-mc-store` → **Settings** → **Domains & Routes**.
2. Choose **Add** → **Custom domain** and enter `shop.voidmc.bond`.
3. Follow the Cloudflare prompts. The domain must be in the same Cloudflare account and its DNS zone must be active. Cloudflare will configure the required DNS record and certificate.
4. Wait for the custom domain and TLS certificate to become active, then visit `https://shop.voidmc.bond`.

Do not proxy an unrelated origin IP to this hostname. The custom domain should be attached to this Worker.

## Important payment note

The `I HAVE PAID` button only creates a 20-character submission code (`VM` + 16 characters + `HE`). It does NOT verify a bank/UPI transfer. An admin must check the payment in the payment account and then mark the order verified in the dashboard.

## Local development

Copy `.dev.vars.example` to `.dev.vars`, set local secrets, then run:
```bash
npx wrangler d1 migrations apply void-mc-store-db --local
npm run dev
```

Local D1 is separate from the remote database. Do not use `--local` when preparing the live database.

## Existing data

The original SQLite data file, if any, is not automatically imported. This ZIP includes the original logo and payment QR assets but starts with a fresh D1 database.


## Separate shop and admin domains

Both hostnames use this **same Worker and the same D1 database**:

- `shop.voidmc.bond` — public rank store.
- `admin.voidmc.bond` — separate private admin dashboard.

After deploying, open Cloudflare Dashboard → **Workers & Pages** → `void-mc-store` → **Settings** → **Domains & Routes** → **Add** → **Custom domain**. Add `shop.voidmc.bond`, then repeat and add `admin.voidmc.bond` to the same Worker. Cloudflare should provision DNS and TLS for each hostname. Do not create a separate Worker or separate D1 database for the admin hostname.

The Worker detects `admin.voidmc.bond` and serves `public/admin.html`, `public/admin.css`, and `public/admin.js` there. The admin dashboard calls the existing `/api/admin/*` endpoints on the same hostname. The login cookie is host-only, HttpOnly, Secure and SameSite=Strict; the admin session is not shared with the public shop hostname.

The shop page no longer shows the old in-page admin shortcut. Admin access is at `https://admin.voidmc.bond/`.

## Mobile deployment note

You can deploy from Android using Termux. Extract the ZIP, enter the `voidmc_cf` directory, run `npm install`, `npx wrangler login`, configure the D1 database ID and Worker secrets as described above, then run `npm run deploy`. If you already created the D1 database for this project, reuse its existing database ID and do not create a second database.

# VOID MC Official Store — Cloudflare Workers + D1

This is the Cloudflare-native conversion of the VOID MC store. Static files are served from `public/`; API routes run in `worker.js`; orders and coupons are stored in Cloudflare D1.

## Before you deploy
- A Cloudflare account and a domain already added to Cloudflare.
- Node.js 20+ and npm installed on your computer.
- Never publish your admin password or session secret. Set them as Worker secrets.

## Step-by-step deployment

1. Extract this ZIP on your computer.
2. Open a terminal in the extracted `VOID_MC_Cloudflare` folder and run:
   ```bash
   npm install
   npx wrangler login
   ```
3. The D1 database ID is prefilled to match the separate admin Worker package. Confirm it matches `admin/wrangler.jsonc`; both Workers must use the same database. If setting up a brand-new database, create it once and replace the ID in BOTH Wrangler configs with the same new ID.\n4. Create the database tables:
   ```bash
   npx wrangler d1 migrations apply void-mc-store-db --remote
   ```
5. Set the private admin password and session signing secret:
   ```bash
   npx wrangler secret put ADMIN_PASSWORD
   npx wrangler secret put SESSION_SECRET
   ```
   Enter each value when prompted. Choose a new, unique admin password (preferably 16+ characters). For SESSION_SECRET, use a different random string with at least 32 characters. Do not put either value in `public/`, HTML, or JavaScript.
6. Optional UPI ID (if you want it displayed):
   ```bash
   npx wrangler secret put UPI_ID
   ```
   Enter your UPI ID. If omitted, the site will show the QR payment instruction only.
7. Deploy:
   ```bash
   npm run deploy
   ```
   Cloudflare prints a `workers.dev` URL. Open it and test a sample cart/order, coupon validation, payment-submission code, and admin login.

## Connect `shop.voidmc.bond`

1. In Cloudflare Dashboard, open **Workers & Pages** → `void-mc-store` → **Settings** → **Domains & Routes**.
2. Choose **Add** → **Custom domain** and enter `shop.voidmc.bond`.
3. Follow the Cloudflare prompts. The domain must be in the same Cloudflare account and its DNS zone must be active. Cloudflare will configure the required DNS record and certificate.
4. Wait for the custom domain and TLS certificate to become active, then visit `https://shop.voidmc.bond`.

Do not proxy an unrelated origin IP to this hostname. The custom domain should be attached to this Worker.

## Important payment note

The `I HAVE PAID` button only creates a 20-character submission code (`VM` + 16 characters + `HE`). It does NOT verify a bank/UPI transfer. An admin must check the payment in the payment account and then mark the order verified in the dashboard.

## Local development

Copy `.dev.vars.example` to `.dev.vars`, set local secrets, then run:
```bash
npx wrangler d1 migrations apply void-mc-store-db --local
npm run dev
```

Local D1 is separate from the remote database. Do not use `--local` when preparing the live database.

## Existing data

The original SQLite data file, if any, is not automatically imported. This ZIP includes the original logo and payment QR assets but starts with a fresh D1 database.


## Separate shop and admin domains

Both hostnames use this **same Worker and the same D1 database**:

- `shop.voidmc.bond` — public rank store.
- `admin.voidmc.bond` — separate private admin dashboard.

After deploying, open Cloudflare Dashboard → **Workers & Pages** → `void-mc-store` → **Settings** → **Domains & Routes** → **Add** → **Custom domain**. Add `shop.voidmc.bond`, then repeat and add `admin.voidmc.bond` to the same Worker. Cloudflare should provision DNS and TLS for each hostname. Do not create a separate Worker or separate D1 database for the admin hostname.

The Worker detects `admin.voidmc.bond` and serves `public/admin.html`, `public/admin.css`, and `public/admin.js` there. The admin dashboard calls the existing `/api/admin/*` endpoints on the same hostname. The login cookie is host-only, HttpOnly, Secure and SameSite=Strict; the admin session is not shared with the public shop hostname.

The shop page no longer shows the old in-page admin shortcut. Admin access is at `https://admin.voidmc.bond/`.

## Mobile deployment note

You can deploy from Android using Termux. Extract the ZIP, enter the `voidmc_cf` directory, run `npm install`, `npx wrangler login`, configure the D1 database ID and Worker secrets as described above, then run `npm run deploy`. If you already created the D1 database for this project, reuse its existing database ID and do not create a second database.

## Updates in this package
- Checkout now requires the customer's Minecraft username and stores it with the order.
- The limited free SEAMAN promotion accepts at most three successful claims. The server enforces the limit atomically; the storefront displays claimed/remaining slots.
- Admin orders include a permanent-delete action, and the dashboard includes a Free Claims view.
- Rank cards load from the D1 `ranks` table, so ranks/categories managed by the separate admin Worker are reflected in the shop.
- Apply all pending migrations with `npx wrangler d1 migrations apply void-mc-store-db --remote` before deploying.

## Free Rank manager (Admin Dashboard)
Open **Admin → Free Rank**. Everything is stored in the shared D1 `settings` table (`free_rank_*` keys), so the store picks changes up instantly, with no code edits or redeploy:
- **Rank name**, **price** (shown on the store as the rank's normal value; 0 hides it), **description**
- **Maximum claims** (default 3), enforced atomically in SQL so simultaneous claims can never exceed it
- **ON / OFF** switch: OFF hides the Free Rank card and blocks claims
- Live stats: status, claimed/max, remaining slots
- Every claimant: Minecraft username, customer name, email, phone, location, rank, time. A claim can be removed to free its slot.
Existing claims keep the rank name they were made under. API: `GET/PUT /api/admin/free-rank`, `DELETE /api/admin/free-claims/:id` (admin); `GET /api/free-rank`, `POST /api/free-rank/claim` (public store).

Run `npx wrangler d1 migrations apply void-mc-store-db --remote` to add migration `0004_free_rank_settings.sql` (optional: defaults are also applied automatically if it is skipped).


## VOID MC SHOP V3.0.0 upgrade notes

- Adds shop-wide live announcements managed from the separate admin dashboard.
- Adds R2-backed logo and background image management. Both Workers must bind the same R2 bucket as `MEDIA` (`voidmc-media`). Create this bucket in Cloudflare R2 before deployment.
- Apply the new D1 migration with `npx wrangler d1 migrations apply void-mc-store-db --remote`.
- Deploy the shop Worker and the separate admin Worker after creating the R2 bucket. Keep both Workers connected to the same D1 database and same R2 bucket.
- Uploaded logo/background files accept PNG, JPG or WebP up to 2 MB and are stored in R2, not in D1.
- The shop displays Java `play.voidmc.bond` and Bedrock `play.voidmc.bond` port `47022`.

**Important account limitation:** this existing project has no customer/member authentication system. The V3.0.0 package preserves the existing public checkout and admin-only management; it does not expose customer order/claim history or cancellation through an insecure email-only lookup. A proper member dashboard requires adding customer registration/login and account recovery, which should be implemented as a separate authenticated feature before enabling member-specific access.

## Automatic background music

Admin-controlled background music for the shop. Visitors get **no** music UI at all.

- **Visitor side** (`public/music.js`, loaded with `defer` from `index.html`): after the page has finished loading it asks `GET /api/music`. If the admin has music ON it streams `/media/music?v=<version>` in an endless loop. The `<audio>` element is created in JavaScript and never added to the page, so there is nothing to click, pause or mute.
- **Autoplay blocked?** Browsers often refuse sound before the visitor interacts. The script then waits and starts the music on the **first click, tap or key press** (scrolling or moving the mouse does not count for browsers, so it cannot start then).
- **Live updates**: every open page re-checks the admin's settings every 45 s (and when the visitor returns to the tab), so Enable / Disable / Change applies without a reload.
- **Navigation**: the shop is a single page (anchors, modals), so playback is never interrupted while browsing. On a reload the position is remembered for that tab and playback resumes from it.
- **Background tab**: music pauses while the tab/app is hidden and resumes when the visitor returns (`PAUSE_WHEN_HIDDEN` at the top of `music.js`; `VOLUME` is there too).
- **Optimised loading**: nothing is requested until the page has loaded; versioned URLs are cached for a year by the browser; the file is streamed with HTTP **Range** support (required by iOS Safari); with Data Saver on, the file is fetched only once playback is allowed.
- **Storage**: flags in the D1 `settings` table (`music_enabled`, `music_key`, `music_name`, `music_type`, `music_size`, `music_version`, `music_updated_at`), the audio file in the shared R2 bucket `MEDIA`. This Worker only *reads* them; only the admin Worker can change them. While music is OFF, `/media/music` returns 404.
- Apply the (optional, self-healing) migration: `npx wrangler d1 migrations apply void-mc-store-db --remote` (adds `0008_background_music.sql`; default is music OFF, no file).
- Deploy: `npm run deploy` in this folder **and** in the admin folder. The R2 bucket `voidmc-media` must already exist and be bound as `MEDIA` in both (same as the logo/background feature).

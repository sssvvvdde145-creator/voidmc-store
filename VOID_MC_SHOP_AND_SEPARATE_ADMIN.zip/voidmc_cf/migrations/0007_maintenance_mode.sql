-- V3.0.0 Maintenance Mode. Idempotent; existing data is untouched. Default = OFF.
INSERT OR IGNORE INTO settings(key,value) VALUES
  ('maintenance_enabled','0'),
  ('maintenance_message','We are performing scheduled maintenance to improve VOID MC SHOP. Please check back soon.'),
  ('maintenance_updated_at','');

-- Background music. Idempotent; existing data is untouched. Default = OFF with no file (the admin enables it from Admin > Music).
INSERT OR IGNORE INTO settings(key,value) VALUES
  ('music_enabled','0'),
  ('music_key',''),
  ('music_name',''),
  ('music_type',''),
  ('music_size','0'),
  ('music_version',''),
  ('music_updated_at','');

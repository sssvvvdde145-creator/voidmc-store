-- V3.0.0 settings and live announcements. Idempotent migration; existing customer data is untouched.
INSERT OR IGNORE INTO settings(key,value) VALUES ('logo_key',''),('background_key','');
CREATE TABLE IF NOT EXISTS announcements (id TEXT PRIMARY KEY, message TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_announcements_active ON announcements(active,updated_at);

ALTER TABLE orders ADD COLUMN minecraft_username TEXT NOT NULL DEFAULT '';
CREATE TABLE IF NOT EXISTS free_rank_claims (
 id TEXT PRIMARY KEY,
 customer_name TEXT NOT NULL,
 minecraft_username TEXT NOT NULL,
 location TEXT NOT NULL,
 phone TEXT NOT NULL,
 email TEXT NOT NULL,
 rank_name TEXT NOT NULL DEFAULT 'SEAMAN',
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_free_claims_created ON free_rank_claims(created_at);

-- Free Rank settings, editable from the admin dashboard (defaults match the original SEAMAN / 3-claim promotion).
INSERT OR IGNORE INTO settings(key,value) VALUES
 ('free_rank_name','SEAMAN'),
 ('free_rank_price','79'),
 ('free_rank_max','3'),
 ('free_rank_description','Make waves across the server.'),
 ('free_rank_enabled','1');

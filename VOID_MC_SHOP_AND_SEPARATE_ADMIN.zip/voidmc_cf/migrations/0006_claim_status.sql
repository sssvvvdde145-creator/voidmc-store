ALTER TABLE free_rank_claims ADD COLUMN status TEXT NOT NULL DEFAULT 'active';

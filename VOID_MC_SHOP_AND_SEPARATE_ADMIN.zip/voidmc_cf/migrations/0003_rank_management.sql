CREATE TABLE IF NOT EXISTS ranks (
 name TEXT PRIMARY KEY,
 price INTEGER NOT NULL CHECK(price BETWEEN 1 AND 100000),
 tier TEXT NOT NULL DEFAULT '',
 description TEXT NOT NULL DEFAULT '',
 icon TEXT NOT NULL DEFAULT '✦',
 category TEXT NOT NULL DEFAULT 'Ranks',
 active INTEGER NOT NULL DEFAULT 1,
 sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS categories (name TEXT PRIMARY KEY, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT OR IGNORE INTO ranks(name,price,tier,description,icon,category,active,sort) VALUES
 ('BOOSTER',49,'STARTER BOOST','Step into the spotlight.','✦','Ranks',1,1),
 ('SEAMAN',79,'OCEAN WARRIOR','Make waves across the server.','⚓','Ranks',1,2),
 ('CAPTAIN',129,'ELITE COMMAND','Lead your own adventure.','♛','Ranks',1,3),
 ('ROYAL',179,'ROYAL STATUS','A crown worthy of legends.','✧','Ranks',1,4),
 ('MONARCH',229,'ULTIMATE POWER','Rule the world of VOID MC.','♨','Ranks',1,5);
INSERT OR IGNORE INTO categories(name,created_at) VALUES('Ranks',CURRENT_TIMESTAMP);

/* VOID MC — automatic background music (visitor side).
 *
 * Managed from Admin → Music (settings are stored in D1, the audio file in R2).
 * Visitors get NO music controls: the <audio> element is created in JavaScript and never added to the page,
 * so there is nothing on the site that can pause, stop or mute it.
 *
 *  - Loads after the page has finished loading, so it never competes with the shop's own assets.
 *  - Loops forever (native loop + an 'ended' fallback).
 *  - If the browser blocks autoplay-with-sound, it starts on the first tap / click / key press.
 *  - Re-checks the admin's settings every POLL_MS, so enabling, disabling or replacing the music applies live.
 *  - The shop is a single page (modals and #anchors, no page reloads), so the music is never interrupted while visitors
 *    browse. If the page IS reloaded or navigated, the position is remembered for the tab and playback resumes from it.
 */
(() => {
  'use strict';

  const API = '/api/music';
  const POLL_MS = 45000;           // how often an open page re-reads the admin's music settings
  const VOLUME = 1;                // 0..1 (iOS ignores this and always follows the device volume)
  const PAUSE_WHEN_HIDDEN = true;  // pause while the tab / app is in the background, resume when the visitor comes back
  const POS_KEY = 'vm_music_pos';
  const UNLOCK_EVENTS = ['pointerdown', 'pointerup', 'mousedown', 'touchend', 'click', 'keydown'];

  let audio = null;     // ONE persistent element: iOS only lets an element that a tap has unlocked keep playing later
  let current = null;   // { version, url } of the track that is loaded, or null while music is off
  let armed = false;    // true while we are waiting for the first user gesture
  let retryTimer = 0;
  let retries = 0;
  let lastSave = 0;

  const saveData = () => !!(navigator.connection && navigator.connection.saveData);
  const store = {
    get() { try { return JSON.parse(sessionStorage.getItem(POS_KEY) || 'null'); } catch { return null; } },
    set(v) { try { sessionStorage.setItem(POS_KEY, JSON.stringify(v)); } catch { /* private mode / blocked storage */ } }
  };
  const savePos = () => { if (audio && current && audio.currentTime > 0) store.set({ v: current.version, t: audio.currentTime }); };
  const shouldPlay = () => !!current && (!PAUSE_WHEN_HIDDEN || document.visibilityState === 'visible');

  function ensureAudio() {
    if (audio) return audio;
    audio = new Audio();
    audio.loop = true;
    audio.volume = VOLUME;
    audio.controls = false;
    audio.preload = saveData() ? 'metadata' : 'auto';   // honour "Data Saver": only fetch once playback is allowed
    audio.disableRemotePlayback = true;                  // no cast / AirPlay picker for the background track
    audio.setAttribute('x-webkit-airplay', 'deny');
    audio.addEventListener('playing', onPlaying);
    audio.addEventListener('ended', () => { audio.currentTime = 0; tryPlay(); });   // fallback if a browser ignores loop
    audio.addEventListener('error', onError);
    audio.addEventListener('timeupdate', () => { const n = Date.now(); if (n - lastSave > 2000) { lastSave = n; savePos(); } });
    audio.addEventListener('loadedmetadata', () => {
      const s = store.get();   // resume where this tab left off (reload / navigation)
      if (s && current && s.v === current.version && isFinite(audio.duration) && s.t > 0 && s.t < audio.duration - 1) {
        try { audio.currentTime = s.t; } catch { /* not seekable yet */ }
      }
    });
    return audio;
  }

  function onPlaying() {
    disarm();
    retries = 0;
    if ('mediaSession' in navigator && typeof MediaMetadata !== 'undefined') {
      try { navigator.mediaSession.metadata = new MediaMetadata({ title: 'VOID MC', artist: 'Official Store' }); } catch { /* optional */ }
    }
  }

  function onError() {
    if (!current) return;
    clearTimeout(retryTimer);
    if (retries++ < 5) retryTimer = setTimeout(() => { if (current) { audio.load(); tryPlay(); } }, Math.min(60000, 3000 * retries * retries));
  }

  function tryPlay() {
    if (!audio || !shouldPlay()) return;
    let p;
    try { p = audio.play(); } catch { return; }
    if (p && p.then) p.then(onPlaying).catch(err => {
      // NotAllowedError = autoplay with sound is blocked until the visitor interacts: wait for the first gesture.
      // AbortError = a newer load()/pause() interrupted this play(): nothing to do.
      if (err && err.name === 'NotAllowedError') arm();
    });
  }

  function onGesture() {
    if (!audio || !shouldPlay()) return;
    let p;
    try { p = audio.play(); } catch { return; }
    if (p && p.then) p.then(onPlaying).catch(() => { /* not a gesture the browser accepts (e.g. a modifier key): stay armed */ });
  }
  function arm() {
    if (armed) return;
    armed = true;
    UNLOCK_EVENTS.forEach(e => document.addEventListener(e, onGesture, { capture: true, passive: true }));
  }
  function disarm() {
    if (!armed) return;
    armed = false;
    UNLOCK_EVENTS.forEach(e => document.removeEventListener(e, onGesture, { capture: true }));
  }

  function load(cfg) {
    const a = ensureAudio();
    current = { version: cfg.version, url: cfg.url };   // a new version means a new URL, so the browser fetches the new file
    retries = 0;
    clearTimeout(retryTimer);
    a.src = cfg.url;
    tryPlay();
  }

  function teardown() {
    disarm();
    clearTimeout(retryTimer);
    if (!current) return;
    savePos();
    current = null;
    if (audio) { audio.pause(); audio.removeAttribute('src'); audio.load(); }   // stop and release the download
  }

  function apply(cfg) {
    if (cfg && cfg.enabled && cfg.url) { if (!current || current.version !== cfg.version) load(cfg); }
    else teardown();
  }

  async function refresh() {
    try {
      const r = await fetch(API, { cache: 'no-store', credentials: 'same-origin' });
      if (r.ok) apply(await r.json());
    } catch { /* offline: keep whatever is playing */ }
  }

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      savePos();
      if (PAUSE_WHEN_HIDDEN && audio && !audio.paused) audio.pause();
    } else { refresh(); tryPlay(); }
  });
  addEventListener('pagehide', savePos);
  addEventListener('pageshow', e => { if (e.persisted) { refresh(); tryPlay(); } });   // back/forward cache restore

  function start() { refresh(); setInterval(refresh, POLL_MS); }
  function init() {
    const go = () => ('requestIdleCallback' in window ? requestIdleCallback(start, { timeout: 1000 }) : setTimeout(start, 300));
    if (document.readyState === 'complete') go(); else addEventListener('load', go, { once: true });
  }
  init();
})();

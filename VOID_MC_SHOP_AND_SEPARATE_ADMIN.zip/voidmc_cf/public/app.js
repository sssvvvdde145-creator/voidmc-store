const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let prices={};
let cart={},coupon="",discountPct=0,activeOrder=null,admin=false;
const money=n=>"₹"+Number(n||0).toLocaleString("en-IN");
const esc=s=>String(s??"").replace(/[&<>"\']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;", "\'":"&#39;"}[c]));
function toast(t){const el=$("#toast");el.textContent=t;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2300)}
function show(id){$("#"+id).classList.add("show")}function hide(id){$("#"+id).classList.remove("show")}
$$("[data-close]").forEach(b=>b.onclick=()=>hide(b.dataset.close));
$$(".overlay").forEach(o=>o.addEventListener("click",e=>{if(e.target===o)o.classList.remove("show")}));
function totals(){let sub=Object.entries(cart).reduce((s,[r,q])=>s+prices[r]*q,0);return{sub,discount:Math.floor(sub*discountPct/100),total:sub-Math.floor(sub*discountPct/100)}}
function renderCart(){let entries=Object.entries(cart);$("#cart-count").textContent=entries.reduce((s,[r,q])=>s+q,0);$("#cart-items").innerHTML=entries.length?entries.map(([r,q])=>`<div class="cart-line"><span><b>${r}</b> × ${q} <small>${money(prices[r]*q)}</small></span><span><button data-remove="${r}">Remove</button></span></div>`).join(""):'<p class="muted">Your cart is empty. Choose a rank to get started.</p>';$$("[data-remove]").forEach(b=>b.onclick=()=>{delete cart[b.dataset.remove];renderCart()});const t=totals();$("#subtotal").textContent=money(t.sub);$("#discount").textContent="-"+money(t.discount);$("#total").textContent=money(t.total);$("#checkout-start").disabled=!entries.length}
$("#rank-grid").addEventListener("click",e=>{const b=e.target.closest(".add");if(!b)return;cart[b.dataset.rank]=(cart[b.dataset.rank]||0)+1;renderCart();toast(b.dataset.rank+" added to cart")});
$("#cart-open").onclick=()=>{renderCart();show("cart-modal")};
$("#apply-coupon").onclick=async()=>{const code=$("#coupon-input").value.trim().toUpperCase();if(!code)return toast("Enter a coupon code");try{const r=await fetch("/api/coupons/validate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code})});const d=await r.json();if(!r.ok)throw Error(d.error);coupon=code;discountPct=d.discount;$("#coupon-message").textContent=`${code} applied — ${d.discount}% off`;renderCart()}catch(e){coupon="";discountPct=0;$("#coupon-message").textContent=e.message;renderCart()}};
$("#checkout-start").onclick=()=>{if(!Object.keys(cart).length)return;hide("cart-modal");show("checkout-modal")};
$("#checkout-form").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);const body={name:f.get("name"),location:f.get("location"),phone:f.get("phone"),username:f.get("username"),email:f.get("email"),coupon,items:Object.entries(cart).map(([name,qty])=>({name,qty}))};try{const r=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw Error(d.error);activeOrder={id:d.orderId,total:d.total};$("#purchase-prompt").textContent=d.prompt;$("#payment-total").textContent=money(d.total);hide("checkout-modal");show("prompt-modal");copyText(d.prompt,false)}catch(err){toast(err.message)}};
async function copyText(text,notify=true){try{await navigator.clipboard.writeText(text);if(notify)toast("Copied to clipboard")}catch{const t=document.createElement("textarea");t.value=text;document.body.append(t);t.select();document.execCommand("copy");t.remove();if(notify)toast("Copied")}}
$("#copy-prompt").onclick=()=>copyText($("#purchase-prompt").textContent);
$("#already-copy").onclick=()=>{hide("prompt-modal");show("discord-modal")};
$("#show-payment").onclick=()=>{hide("discord-modal");show("payment-modal");fetch("/api/config").then(r=>r.json()).then(d=>$("#upi-line").textContent=d.upiId?"UPI ID: "+d.upiId:"Use the payment QR code above.")};
$("#paid-button").onclick=async()=>{if(!activeOrder)return;try{const r=await fetch(`/api/orders/${activeOrder.id}/paid`,{method:"POST"});const d=await r.json();if(!r.ok)throw Error(d.error);$("#code-result").hidden=false;$("#code-result").innerHTML=`<b>Payment submission code</b><code>${d.verificationCode}</code><button class="btn ghost" id="copy-code">Copy code</button><p class="muted">Give this code to an admin in your Discord Buy Item ticket. The code is not proof that funds have cleared.</p>`;$("#copy-code").onclick=()=>copyText(d.verificationCode);$("#paid-button").disabled=true;$("#paid-button").textContent="CODE GENERATED";}catch(e){toast(e.message)}};
let allRanks=[],shopTab="paid",freeRank=null;
const isPaid=r=>(r.category||"Ranks")==="Ranks";
function renderShop(){
  $$(".shop-tab").forEach(b=>b.classList.toggle("on",b.dataset.shopTab===shopTab));
  const grid=$("#rank-grid"),free=$("#free-rank-wrap"),showFree=shopTab==="free"&&freeRank&&freeRank.enabled;
  free.hidden=!showFree;grid.hidden=shopTab==="free";
  if(shopTab==="free"){if(!showFree)grid.hidden=false;else return}
  const list=allRanks.filter(r=>shopTab==="others"?!isPaid(r):isPaid(r));
  if(!list.length){grid.innerHTML=`<p class="shop-empty">${shopTab==="others"?"Nothing here yet. Check back soon!":"No ranks available right now."}</p>`;return}
  const groups={};list.forEach(r=>(groups[r.category||"Ranks"]??=[]).push(r));
  grid.innerHTML=Object.entries(groups).map(([cat,rs])=>`<div class="rank-category">${shopTab==="others"?`<h3>${esc(cat)}</h3>`:""}<div class="rank-grid-inner">${rs.map(r=>`<article class="rank-card"><div class="rank-icon purple">${esc(r.icon||"✦")}</div><p class="tier">${esc(r.tier||"")}</p><h3>${esc(r.name)}</h3><div class="price">₹${Number(r.price)}</div><p class="rank-desc">${esc(r.description||"")}</p><button class="btn add" data-rank="${esc(r.name)}">Add to cart</button></article>`).join("")}</div></div>`).join("");
}
function syncTabs(){const t=$("#tab-free");t.hidden=!(freeRank&&freeRank.enabled);if(t.hidden&&shopTab==="free")shopTab="paid";renderShop()}
$$("[data-shop-tab]").forEach(b=>b.onclick=()=>{shopTab=b.dataset.shopTab;renderShop()});
async function loadRanks(){try{const d=await fetch("/api/config").then(r=>r.json());if(!d.ranks)throw Error("no ranks");allRanks=d.ranks;prices=Object.fromEntries(d.ranks.map(r=>[r.name,Number(r.price)]));renderShop();renderCart()}catch(e){toast("Could not load ranks")}}
renderCart();loadRanks();
async function refreshFreeSlots(){const wrap=$("#free-rank-wrap");try{const d=await fetch("/api/free-rank").then(r=>r.json());if(d.error)throw Error(d.error);freeRank=d;
  if(d.enabled){const value=d.price>0?`<small class="free-was">Value ₹${d.price}</small>`:"";
  wrap.innerHTML=`<article class="rank-card featured"><div class="popular">LIMITED · ${d.max} CLAIM${d.max===1?"":"S"}</div><div class="rank-icon gold">🎁</div><p class="tier">FREE RANK</p><h3>${esc(d.name)}</h3><div class="price">FREE</div>${value}<p class="rank-desc">${esc(d.description)}</p><p class="rank-desc" id="free-slots">${d.claimed}/${d.max} claimed · ${d.remaining} remaining</p><button class="btn add" id="claim-free" ${d.available?"":"disabled"}>${d.available?"Claim Free "+esc(d.name):"Free Rank fully claimed"}</button></article>`;
  $("#free-title").textContent="Claim "+d.name;
  $("#claim-free").onclick=()=>{if(freeRank&&freeRank.available)show("free-modal")}}else wrap.innerHTML=""
}catch{freeRank=null;wrap.innerHTML=""}syncTabs()}
$("#free-form").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target),msg=$("#free-message");msg.textContent="Submitting claim…";try{const r=await fetch("/api/free-rank/claim",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.fromEntries(f))});const d=await r.json();if(!r.ok)throw Error(d.error||"Claim failed");msg.textContent=(d.rank||"Free")+" rank claimed successfully! Claim #"+d.claimNumber;e.target.reset();refreshFreeSlots()}catch(err){msg.textContent=err.message;refreshFreeSlots()}};
refreshFreeSlots();

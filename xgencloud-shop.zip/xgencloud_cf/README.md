# XgenCloud Hosting Store — Cloudflare Workers + D1

XgenCloud is a hosting e-commerce store on Cloudflare Workers. Static files are served from `public/`; API routes run in `worker.js`; orders, products, categories, coupons and IP-ban data live in Cloudflare D1; images and music live in Cloudflare R2.

This package is the **public shop** (`shop.xgencloud.bond`) only. All administration lives in the separate **XgenCloud Admin** package (`admin.xgencloud.bond`). The shop Worker has no admin login and no admin API.

## Before you deploy
- A Cloudflare account with the `xgencloud.bond` zone added and active.
- Node.js 20+ and npm installed on your computer.
- The D1 database `xgencloud-store-db` (the same database the admin Worker uses — all customer, order and payment data lives here).
- The R2 bucket `xgencloud-media` bound as `MEDIA`.
- If you are moving from the old VOID MC resource names (`void-mc-store-db` / `voidmc-media`), run `MIGRATE-STEPS.txt` once first: it creates the new database and bucket and copies all existing data over.

## Deploy / upgrade steps

1. Extract this ZIP and open a terminal in the `xgencloud_cf` folder.
2. `npm install` and `npx wrangler login`.
3. Apply the new migration (adds hosting categories, products, IP bans, activity log; removes the old rank catalogue only — orders/customers/payments untouched):
   ```bash
   npx wrangler d1 migrations apply xgencloud-store-db --remote
   ```
4. Optional UPI ID shown at payment:
   ```bash
   npx wrangler secret put UPI_ID
   ```
   `SESSION_SECRET` is only used to hash rate-limit keys. If the store Worker still has old `ADMIN_PASSWORD` / `SESSION_SECRET` secrets, you may keep or delete `ADMIN_PASSWORD`; keep `SESSION_SECRET` if set.
5. Deploy:
   ```bash
   npm run deploy
   ```
6. Custom domain: `wrangler.jsonc` already declares `shop.xgencloud.bond` as a custom domain, so deploy attaches it automatically (the zone must be in the same Cloudflare account). If you prefer the dashboard: Workers & Pages → `void-mc-store` → Settings → Domains & Routes → Add `shop.xgencloud.bond`. Remove the old `shop.voidmc.bond` domain when you are ready.

The Worker name stays `void-mc-store` so the existing deployment and its Worker secrets are preserved; only the public hostname changed earlier. The D1 database and R2 bucket are now named `xgencloud-store-db` and `xgencloud-media`. If your data still lives in the old VOID MC resources (`void-mc-store-db` / `voidmc-media`), follow `MIGRATE-STEPS.txt` once to create the new resources and copy everything over before deploying.

## What the shop does now
- Dynamic hosting categories and subcategories, managed entirely from the Admin Panel (nothing is hardcoded). Migration `0010` seeds the launch catalogue (VPS Hosting with 10 plans + IPv4 add-ons, Bot Hosting, Web Hosting, Minecraft Hosting with Budget/Performance plans); everything seeded can be edited or deleted from the Admin Panel.
- Each main category has its own page at `/category/<id>`, showing its subcategories and products. The homepage shows the hero plus one card per category linking to those pages; the same links appear in the hamburger drawer (with subcategory quick links that scroll to the right section).
- Product cards with monthly / quarterly / yearly pricing, stock and images. The `featured` flag remains in the database and Admin Panel but is no longer rendered anywhere in the shop.
- Three-line hamburger menu with a slide-out drawer: Home, Categories (dynamic, expandable, linking to each category page), Discord.
- "Join Our Discord" buttons on the homepage and in the footer; the invite link is set in Admin → Branding (default `https://discord.gg/kBHUk8FcB`). The footer also credits `Made by HzardExecx!`. The hero labels no longer have sparkle decorations, and the full-page dot overlay is removed so custom background images show without that pattern.
- No customer login or registration anywhere: visitors browse and check out with contact details only.
- Checkout keeps the existing manual UPI/QR + verification-code flow, now for hosting products. The payment QR shown at checkout is managed from Admin → Branding (upload / change / remove); it is stored in R2 and served at `/media/payment-qr`. If no custom QR is uploaded, the shop falls back to the bundled `public/assets/payment-qr.jpg`. No database migration is needed for this: both Workers create the `payment_qr_key` / `payment_qr_version` settings rows automatically.
- Banned IPs are blocked server-side from coupon validation, order submission and payment-code generation (Cloudflare's `CF-Connecting-IP` only; client-supplied headers are never trusted). Checkout is also rate-limited per IP.
- Live announcements, maintenance mode, logo/background and background music all keep working from the shared D1 `settings` table.

## Important payment note
The `I HAVE PAID` button only creates a payment submission code. It does NOT verify a bank/UPI transfer. An admin must check the payment account and mark the order verified in the Admin Panel.

## Local development
Copy `.dev.vars.example` to `.dev.vars`, then:
```bash
npm install
npx wrangler d1 migrations apply xgencloud-store-db --local
npm run dev
```
Local D1 is separate from the remote database.

## Notes
- Old verification codes (`VM…HE`) remain valid; new codes use the `XG…CL` format. The Admin Panel verifies both.
- The old rank catalogue rows are deleted by migration `0009` (orders keep their own item snapshots, so history is unaffected). Free-rank claim records, orders, coupons and settings are preserved.
- The old `admin.html` in-page admin was removed from the shop package; administration is exclusively at `https://admin.xgencloud.bond`.

## Automatic deploys with GitHub Actions

The workflow at `.github/workflows/deploy.yml` deploys this Worker on every push to `main`. It runs `npm install` and the package's existing `npm run deploy` script from the repository root. You can also start it manually from GitHub Actions with **Run workflow**.

One-time setup for each GitHub repository:
1. In Cloudflare, create an API token using the **Edit Cloudflare Workers** template. Limit it to the account that owns `void-mc-store`, and include the relevant zone access if Cloudflare requests it for the configured custom domain.
2. In the GitHub repository, open **Settings → Secrets and variables → Actions → New repository secret**. Add `CLOUDFLARE_API_TOKEN` with the token value and `CLOUDFLARE_ACCOUNT_ID` with the Cloudflare account ID.
3. Keep both values in GitHub Secrets only. Do not commit them to the repository. Push to `main` to deploy.

This repo's root must be this package directory, containing `package.json` and `wrangler.jsonc`. Before deploying, the workflow also creates the `xgencloud-media` R2 bucket if it is missing and applies this package's D1 migrations to `xgencloud-store-db` automatically.

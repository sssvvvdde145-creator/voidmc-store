// XgenCloud Shop Worker (shop.xgencloud.bond). Public hosting store only.
// All administration lives in the separate XgenCloud Admin Worker (admin.xgencloud.bond);
// this Worker exposes no admin login and no admin API.

const SHOP_NAME = 'XgenCloud';
const BRAND = 'XgenCloud™';
const ADMIN_ORIGIN = 'https://admin.xgencloud.bond';
const DEFAULT_DISCORD = 'https://discord.gg/kBHUk8FcB';
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const ORDER_RATE_MAX = 8, ORDER_RATE_WINDOW_MS = 10 * 60 * 1000; // 8 order attempts per 10 min per IP
const PERIODS = { monthly: 'price_monthly', quarterly: 'price_quarterly', yearly: 'price_yearly' };

const json = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), {
  status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers }
});
const clean = (v, max = 120) => String(v ?? '').trim().slice(0, max);
const now = () => new Date().toISOString();
const randomHex = (bytes = 16) => [...crypto.getRandomValues(new Uint8Array(bytes))].map(x => x.toString(16).padStart(2, '0')).join('').toUpperCase();
function randomCode() {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return 'XG' + [...bytes].map(b => ALPHABET[b % ALPHABET.length]).join('') + 'CL';
}
async function hmac(value, secret) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value));
  return [...new Uint8Array(sig)].map(x => x.toString(16).padStart(2, '0')).join('');
}
async function bodyJson(request) {
  try { return await request.json(); } catch { return {}; }
}
// The only client IP we ever trust: set by the Cloudflare edge, not by the visitor.
// Arbitrary client-supplied headers (X-Forwarded-For etc.) are never read.
const clientIp = request => clean(request.headers.get('CF-Connecting-IP'), 45);

// ---- Maintenance Mode: stored in the shared `settings` table, read live on every request (no redeploy needed).
const MAINT_DEFAULT_MSG = 'We are performing scheduled maintenance to improve XgenCloud. Please check back soon.';
async function maintenanceState(DB) {
  const { results = [] } = await DB.prepare("SELECT key,value FROM settings WHERE key IN ('maintenance_enabled','maintenance_message','maintenance_updated_at')").all();
  const m = Object.fromEntries(results.map(r => [r.key, r.value]));
  return { enabled: m.maintenance_enabled === '1', message: clean(m.maintenance_message, 500) || MAINT_DEFAULT_MSG, updatedAt: m.maintenance_updated_at || '' };
}
const maintenanceBlocked = m => json({ error: 'The shop is under maintenance. Please try again later.', maintenance: true, message: m.message }, 503);

async function discordInvite(DB) {
  const row = await DB.prepare("SELECT value FROM settings WHERE key='discord_invite'").first();
  const v = clean(row?.value, 200);
  return /^https:\/\/(discord\.gg\/|discord\.com\/invite\/)[A-Za-z0-9-]+/.test(v) ? v : DEFAULT_DISCORD;
}

// ---- IP ban enforcement (server-side). Ban records are managed only from the Admin Worker.
async function ipBanBlock(request, env) {
  const ip = clientIp(request);
  if (!ip) return null; // local development without the Cloudflare edge
  try {
    const row = await env.DB.prepare("SELECT status FROM ip_bans WHERE ip=? ORDER BY created_at DESC LIMIT 1").bind(ip).first();
    if (row && row.status === 'active') return json({ error: 'Access from this network has been suspended. If you believe this is a mistake, please contact us on Discord.' }, 403);
  } catch (e) { console.error('ip ban check failed', e); }
  return null;
}
// Lightweight per-IP rate limiting for checkout endpoints (hashed IP keys; raw IPs are not stored here).
async function rateLimited(request, env, bucket, max, windowMs) {
  const ip = clientIp(request) || 'local';
  const key = await hmac(bucket + ':' + ip, env.SESSION_SECRET || 'xgencloud-rate-limit');
  const t = Date.now();
  try {
    const row = await env.DB.prepare('SELECT count, window_start FROM rate_limits WHERE key=?').bind(key).first();
    if (!row || t - row.window_start > windowMs) {
      await env.DB.prepare('INSERT INTO rate_limits (key,count,window_start) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=1,window_start=excluded.window_start').bind(key, t).run();
      return false;
    }
    if (row.count >= max) return true;
    await env.DB.prepare('UPDATE rate_limits SET count=count+1 WHERE key=?').bind(key).run();
  } catch (e) { console.error('rate limit failed', e); }
  return false;
}

// Self-heal: databases created earlier may lack tables/columns this Worker needs.
// Everything here is idempotent and only runs once per Worker instance.
const HEAL_SQL = [
  "CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)",
  "CREATE TABLE IF NOT EXISTS announcements (id TEXT PRIMARY KEY, message TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)",
  "CREATE TABLE IF NOT EXISTS shop_categories (id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', image_key TEXT NOT NULL DEFAULT '', parent_id TEXT NOT NULL DEFAULT '', enabled INTEGER NOT NULL DEFAULT 1, sort INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)",
  "CREATE TABLE IF NOT EXISTS shop_products (id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', specs TEXT NOT NULL DEFAULT '', price_monthly INTEGER NOT NULL DEFAULT 0, price_quarterly INTEGER NOT NULL DEFAULT 0, price_yearly INTEGER NOT NULL DEFAULT 0, image_key TEXT NOT NULL DEFAULT '', category_id TEXT NOT NULL DEFAULT '', subcategory_id TEXT NOT NULL DEFAULT '', stock INTEGER NOT NULL DEFAULT -1, enabled INTEGER NOT NULL DEFAULT 1, featured INTEGER NOT NULL DEFAULT 0, sort INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)",
  "CREATE TABLE IF NOT EXISTS ip_bans (id TEXT PRIMARY KEY, ip TEXT NOT NULL, reason TEXT NOT NULL DEFAULT '', banned_by TEXT NOT NULL DEFAULT 'admin', status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL, updated_at TEXT NOT NULL, unbanned_at TEXT NOT NULL DEFAULT '', unbanned_by TEXT NOT NULL DEFAULT '')",
  "CREATE TABLE IF NOT EXISTS admin_activity_log (id TEXT PRIMARY KEY, action TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', actor TEXT NOT NULL DEFAULT 'admin', created_at TEXT NOT NULL)",
  "CREATE TABLE IF NOT EXISTS rate_limits (key TEXT PRIMARY KEY, count INTEGER NOT NULL DEFAULT 0, window_start INTEGER NOT NULL)",
  "INSERT OR IGNORE INTO settings (key,value) VALUES ('maintenance_enabled','0'),('maintenance_message','" + MAINT_DEFAULT_MSG + "'),('maintenance_updated_at','')",
  "INSERT OR IGNORE INTO settings (key,value) VALUES ('music_enabled','0'),('music_key',''),('music_name',''),('music_type',''),('music_size','0'),('music_version',''),('music_updated_at','')",
  "INSERT OR IGNORE INTO settings (key,value) VALUES ('discord_invite','" + DEFAULT_DISCORD + "')",
  "INSERT OR IGNORE INTO settings (key,value) VALUES ('payment_qr_key',''),('payment_qr_version','')"
];
let schemaReady;
const ensureSchema = env => schemaReady ||= (async () => {
  for (const q of HEAL_SQL) { try { await env.DB.prepare(q).run(); } catch (e) { console.error('heal step failed', q.slice(0, 40), e); } }
  try {
    const ocols = (await env.DB.prepare('PRAGMA table_info(orders)').all()).results || [];
    if (ocols.length && !ocols.some(c => c.name === 'minecraft_username')) await env.DB.prepare("ALTER TABLE orders ADD COLUMN minecraft_username TEXT NOT NULL DEFAULT ''").run();
  } catch (e) { console.error('heal orders.minecraft_username failed', e); }
})().catch(e => { schemaReady = null; throw e; });

// ---- Background music: flags live in the shared `settings` table, the audio file in the shared R2 bucket (MEDIA).
// Only the admin Worker can change them; this Worker only reads them and streams the file to visitors.
async function musicState(DB) {
  const { results = [] } = await DB.prepare("SELECT key,value FROM settings WHERE key IN ('music_enabled','music_key','music_type','music_version')").all();
  const m = Object.fromEntries(results.map(r => [r.key, r.value]));
  return { active: m.music_enabled === '1' && !!m.music_key, key: m.music_key || '', type: m.music_type || 'audio/mpeg', version: m.music_version || '' };
}
function contentRange(r, size) {
  if (!r) return null;
  let start, end;
  if (r.suffix !== undefined) { start = Math.max(0, size - r.suffix); end = size - 1; }
  else { start = r.offset ?? 0; end = r.length !== undefined ? Math.min(size - 1, start + r.length - 1) : size - 1; }
  return `bytes ${start}-${end}/${size}`;
}
// Streams the music with HTTP Range support (iOS Safari will not play audio from a server that ignores Range).
async function serveMusic(request, env, url) {
  if (request.method !== 'GET' && request.method !== 'HEAD') return new Response('Method not allowed', { status: 405, headers: { allow: 'GET, HEAD' } });
  if (!env.MEDIA || !env.DB) return new Response('Music storage is not configured', { status: 503 });
  try {
    const m = await musicState(env.DB);
    if (!m.active) return new Response('Not found', { status: 404, headers: { 'cache-control': 'no-store' } });
    const h = new Headers({ 'content-type': m.type, 'accept-ranges': 'bytes', 'x-content-type-options': 'nosniff', 'cross-origin-resource-policy': 'same-origin',
      // The URL carries ?v=<version>, so a cached copy can never be stale: a new upload changes the version and therefore the URL.
      'cache-control': url.searchParams.get('v') === m.version ? 'public, max-age=31536000, immutable' : 'public, max-age=300' });
    if (request.method === 'HEAD') {
      const head = await env.MEDIA.head(m.key);
      if (!head) return new Response('Not found', { status: 404 });
      h.set('content-length', String(head.size)); h.set('etag', head.httpEtag);
      return new Response(null, { status: 200, headers: h });
    }
    let obj;
    try { obj = await env.MEDIA.get(m.key, { range: request.headers, onlyIf: request.headers }); }
    catch (e) { if (/range/i.test(String(e && e.message))) return new Response('Range not satisfiable', { status: 416 }); throw e; }
    if (!obj) return new Response('Not found', { status: 404 });
    h.set('etag', obj.httpEtag);
    const cr = contentRange(obj.range, obj.size);
    if (cr) h.set('content-range', cr);
    return new Response(obj.body || null, { status: !obj.body ? 304 : cr ? 206 : 200, headers: h });
  } catch (e) { console.error('music unavailable', e); return new Response('Music unavailable', { status: 404 }); }
}

function promptFor(order, discord) {
  const lines = order.items.map(x => `${x.name} (${x.period}) x${x.qty} - Rs.${x.price * x.qty}`).join(', ');
  return `${BRAND} | HOSTING ORDER\nOrder: ${order.id}\nCustomer: ${order.customer_name}\nUsername: ${order.minecraft_username || '-'}\nLocation: ${order.location}\nPhone: ${order.phone}\nEmail: ${order.email}\nItems: ${lines}\nSubtotal: Rs.${order.subtotal}\nDiscount: Rs.${order.discount}\nTotal to pay: Rs.${order.total}\nCoupon: ${order.coupon || 'None'}\nPayment: Please pay using the QR shown on the official store, then submit this prompt in a Buy Item ticket on Discord.\nDiscord: ${discord}`;
}

async function api(request, env) {
  const url = new URL(request.url), path = url.pathname, method = request.method;
  if (!env.DB) return json({ error: 'Store backend is not configured. Check the D1 binding.' }, 500);
  try { await ensureSchema(env); } catch (e) { console.error('ensureSchema failed', e); }

  if (path === '/api/announcement' && method === 'GET') {
    const a = await env.DB.prepare('SELECT message FROM announcements WHERE active=1 ORDER BY updated_at DESC LIMIT 1').first();
    return json({ text: a?.message || '' });
  }

  if (path === '/api/music' && method === 'GET') {
    const m = await musicState(env.DB);
    return json(m.active && env.MEDIA ? { enabled: true, version: m.version, url: '/media/music?v=' + encodeURIComponent(m.version) } : { enabled: false });
  }

  if (path === '/api/maintenance' && method === 'GET') { const m = await maintenanceState(env.DB); return json({ enabled: m.enabled, message: m.enabled ? m.message : '' }); }

  if (path === '/api/config' && method === 'GET') {
    const [cats, prods] = await Promise.all([
      env.DB.prepare('SELECT id,name,description,image_key,parent_id,enabled,sort FROM shop_categories WHERE enabled=1 ORDER BY sort,name').all(),
      env.DB.prepare('SELECT id,name,description,specs,price_monthly,price_quarterly,price_yearly,image_key,category_id,subcategory_id,stock,featured,sort FROM shop_products WHERE enabled=1 ORDER BY sort,name').all()
    ]);
    const publicSettings = (await env.DB.prepare("SELECT key,value FROM settings WHERE key IN ('logo_key','background_key')").all()).results || [];
    const ps = Object.fromEntries(publicSettings.map(x => [x.key, x.value]));
    let upi = null, qrVersion = '';
    try {
      const { results: srows = [] } = await env.DB.prepare("SELECT key,value FROM settings WHERE key IN ('upi_id','payment_qr_version')").all();
      const sm = Object.fromEntries(srows.map(r => [r.key, r.value]));
      upi = { value: sm.upi_id }; qrVersion = sm.payment_qr_version || '';
    } catch (e) { console.error('config: upi/qr settings unavailable', e); }
    const ann = (await env.DB.prepare('SELECT message FROM announcements WHERE active=1 ORDER BY updated_at DESC LIMIT 1').first());
    const maintenance = await maintenanceState(env.DB);
    const img = k => k ? '/media/img/' + k : '';
    return json({
      brand: BRAND,
      maintenance: { enabled: maintenance.enabled, message: maintenance.enabled ? maintenance.message : '' },
      categories: (cats.results || []).map(c => ({ id: c.id, name: c.name, description: c.description, imageUrl: img(c.image_key), parentId: c.parent_id || null, sort: c.sort })),
      products: (prods.results || []).map(p => ({
        id: p.id, name: p.name, description: p.description,
        specs: String(p.specs || '').split('\n').map(s => s.trim()).filter(Boolean),
        prices: { monthly: p.price_monthly, quarterly: p.price_quarterly, yearly: p.price_yearly },
        imageUrl: img(p.image_key), categoryId: p.category_id, subcategoryId: p.subcategory_id,
        stock: p.stock, featured: !!p.featured, sort: p.sort
      })),
      discordInvite: await discordInvite(env.DB),
      upiId: clean(upi?.value || env.UPI_ID, 100),
      paymentQrVersion: qrVersion,
      announcement: ann?.message || '',
      logoUrl: ps.logo_key ? '/media/logo' : '',
      backgroundUrl: ps.background_key ? '/media/background' : ''
    });
  }

  if (path === '/api/coupons/validate' && method === 'POST') {
    const banned = await ipBanBlock(request, env); if (banned) return banned;
    const data = await bodyJson(request), code = clean(data.code, 6).toUpperCase();
    const row = await env.DB.prepare('SELECT discount FROM coupons WHERE code = ? AND active = 1').bind(code).first();
    if (!row) return json({ error: 'Invalid or inactive coupon' }, 404);
    return json({ discount: row.discount });
  }

  if (path === '/api/orders' && method === 'POST') {
    // Server-side access control: banned IPs cannot submit orders (checked before anything else).
    const banned = await ipBanBlock(request, env); if (banned) return banned;
    if (await rateLimited(request, env, 'orders', ORDER_RATE_MAX, ORDER_RATE_WINDOW_MS)) return json({ error: 'Too many order attempts. Please wait a few minutes and try again.' }, 429);
    const maint = await maintenanceState(env.DB); if (maint.enabled) return maintenanceBlocked(maint);
    const data = await bodyJson(request);
    const name = clean(data.name, 80), location = clean(data.location, 120), phone = clean(data.phone, 24), username = clean(data.username, 32), email = clean(data.email, 120);
    if (!name || !location || !/^[+\d\s()-]{7,24}$/.test(phone) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: 'Enter a name, location, valid phone number and email address.' }, 400);
    if (username && !/^[A-Za-z0-9_.-]{2,32}$/.test(username)) return json({ error: 'Enter a valid username, or leave it empty.' }, 400);
    const raw = Array.isArray(data.items) ? data.items : [], items = [];
    for (const item of raw) {
      const productId = clean(item.productId, 60), period = clean(item.period, 12), qty = Number(item.qty);
      if (!Number.isInteger(qty) || qty < 1 || qty > 10) return json({ error: 'Invalid cart item.' }, 400);
      const column = PERIODS[period];
      if (!column) return json({ error: 'Choose a valid billing period for every item.' }, 400);
      const prod = await env.DB.prepare(`SELECT id,name,${column} AS price,stock FROM shop_products WHERE id=? AND enabled=1`).bind(productId).first();
      if (!prod) return json({ error: 'A product in your cart is unavailable. Please refresh and try again.' }, 400);
      if (!Number.isInteger(prod.price) || prod.price < 1) return json({ error: `${prod.name} is not available with ${period} billing.` }, 400);
      if (prod.stock !== -1 && prod.stock < qty) return json({ error: prod.stock <= 0 ? `${prod.name} is out of stock.` : `Only ${prod.stock} left of ${prod.name}.` }, 409);
      const found = items.find(x => x.productId === productId && x.period === period);
      if (found) found.qty += qty; else items.push({ productId, name: prod.name, period, qty, price: prod.price });
    }
    if (!items.length || items.some(x => x.qty > 10)) return json({ error: 'Your cart is empty or has too many items.' }, 400);
    const subtotal = items.reduce((sum, x) => sum + Number(x.price) * x.qty, 0);
    let coupon = '', discount = 0;
    if (data.coupon) {
      coupon = clean(data.coupon, 6).toUpperCase();
      const row = await env.DB.prepare('SELECT discount FROM coupons WHERE code = ? AND active = 1').bind(coupon).first();
      if (!row) return json({ error: 'Coupon is invalid or inactive.' }, 400);
      discount = Math.floor(subtotal * row.discount / 100);
    }
    // Reserve stock first (conditional UPDATE, so concurrent orders can never oversell).
    for (const x of items) {
      const r = await env.DB.prepare('UPDATE shop_products SET stock=stock-?, updated_at=? WHERE id=? AND (stock=-1 OR stock>=?)').bind(x.qty, now(), x.productId, x.qty).run();
      if (!r.meta.changes) {
        for (const y of items.slice(0, items.indexOf(x))) await env.DB.prepare('UPDATE shop_products SET stock=CASE WHEN stock=-1 THEN -1 ELSE stock+? END WHERE id=?').bind(y.qty, y.productId).run().catch(() => {});
        return json({ error: `${x.name} just went out of stock.` }, 409);
      }
    }
    const id = 'XG-' + randomHex(5), total = subtotal - discount, discord = await discordInvite(env.DB);
    const order = { id, customer_name: name, location, phone, minecraft_username: username, email, items, subtotal, discount, total, coupon };
    const prompt = promptFor(order, discord);
    try {
      // Atomic: the maintenance flag is re-checked inside the INSERT, so an order can never slip in after maintenance is switched ON.
      const ins = await env.DB.prepare(`INSERT INTO orders (id,customer_name,location,phone,minecraft_username,email,items,subtotal,discount,total,coupon,prompt,created_at)
        SELECT ?,?,?,?,?,?,?,?,?,?,?,?,? WHERE COALESCE((SELECT value FROM settings WHERE key='maintenance_enabled'),'0')<>'1'`).bind(id, name, location, phone, username, email, JSON.stringify(items), subtotal, discount, total, coupon, prompt, now()).run();
      if (!ins.meta.changes) throw Object.assign(new Error('maintenance'), { maintenance: true });
    } catch (e) {
      for (const x of items) await env.DB.prepare('UPDATE shop_products SET stock=CASE WHEN stock=-1 THEN -1 ELSE stock+? END WHERE id=?').bind(x.qty, x.productId).run().catch(() => {});
      if (e.maintenance) return maintenanceBlocked(await maintenanceState(env.DB));
      throw e;
    }
    return json({ orderId: id, prompt, total });
  }

  const paidMatch = path.match(/^\/api\/orders\/([A-Za-z0-9-]+)\/paid$/);
  if (paidMatch && method === 'POST') {
    const banned = await ipBanBlock(request, env); if (banned) return banned;
    const id = clean(paidMatch[1], 40);
    const order = await env.DB.prepare('SELECT id,code,status FROM orders WHERE id = ?').bind(id).first();
    if (!order) return json({ error: 'Order not found' }, 404);
    if (order.code) return json({ verificationCode: order.code });
    let code;
    for (let i = 0; i < 8; i++) {
      code = randomCode();
      try {
        await env.DB.prepare("UPDATE orders SET code = ?, status = 'payment_submitted' WHERE id = ? AND code IS NULL").bind(code, id).run();
        const latest = await env.DB.prepare('SELECT code FROM orders WHERE id = ?').bind(id).first();
        if (latest?.code) return json({ verificationCode: latest.code });
      } catch (e) { if (i === 7) throw e; }
    }
    return json({ error: 'Could not create a verification code. Please contact support.' }, 500);
  }

  return json({ error: 'Not found' }, 404);
}

// ---- Payment QR: uploaded from the Admin Panel (Branding tab) into R2, tracked by
// settings.payment_qr_key / payment_qr_version. With no upload, falls back to the bundled asset.
async function servePaymentQr(request, env, url) {
  if (request.method !== 'GET' && request.method !== 'HEAD') return new Response('Method not allowed', { status: 405, headers: { allow: 'GET, HEAD' } });
  let key = '', version = '';
  try {
    const { results = [] } = await env.DB.prepare("SELECT key,value FROM settings WHERE key IN ('payment_qr_key','payment_qr_version')").all();
    const m = Object.fromEntries(results.map(r => [r.key, r.value]));
    key = m.payment_qr_key || ''; version = m.payment_qr_version || '';
  } catch (e) { console.error('payment qr settings unavailable', e); }
  if (!key || !env.MEDIA) {
    // No custom QR uploaded: serve the QR image bundled with the shop package.
    return env.ASSETS.fetch(new Request(new URL('/assets/payment-qr.jpg', url), request));
  }
  try {
    if (request.method === 'HEAD') {
      const head = await env.MEDIA.head(key);
      if (!head) return new Response('Not found', { status: 404 });
      return new Response(null, { headers: { 'content-type': (head.httpMetadata && head.httpMetadata.contentType) || 'image/jpeg', 'content-length': String(head.size), etag: head.httpEtag, 'cache-control': 'public, max-age=60', 'x-content-type-options': 'nosniff' } });
    }
    const obj = await env.MEDIA.get(key);
    if (!obj) return new Response('Not found', { status: 404 });
    const h = new Headers();
    obj.writeHttpMetadata(h);
    // The shop appends ?v=<payment_qr_version>: a new upload means a new URL, so an exact version match can be cached forever.
    h.set('cache-control', version && url.searchParams.get('v') === version ? 'public, max-age=31536000, immutable' : 'public, max-age=60');
    h.set('etag', obj.httpEtag);
    h.set('x-content-type-options', 'nosniff');
    return new Response(obj.body, { headers: h });
  } catch (e) { console.error('payment qr unavailable', e); return new Response('Payment QR unavailable', { status: 404 }); }
}

// Serves a category/product image previously uploaded from the Admin Panel into R2.
async function serveImage(env, key) {
  if (!env.MEDIA || !/^xgencloud\/images\/[A-Za-z0-9._-]+$/.test(key)) return new Response('Not found', { status: 404 });
  try {
    const obj = await env.MEDIA.get(key);
    if (!obj) return new Response('Not found', { status: 404 });
    const h = new Headers();
    obj.writeHttpMetadata(h);
    h.set('cache-control', 'public, max-age=86400');
    h.set('x-content-type-options', 'nosniff');
    return new Response(obj.body, { headers: h });
  } catch (e) { console.error('image unavailable', e); return new Response('Image unavailable', { status: 404 }); }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/media/music') return serveMusic(request, env, url);
    if (url.pathname === '/media/payment-qr') return servePaymentQr(request, env, url);
    const imgMatch = url.pathname.match(/^\/media\/img\/(.+)$/);
    if (imgMatch) { try { return serveImage(env, decodeURIComponent(imgMatch[1])); } catch { return new Response('Not found', { status: 404 }); } }
    if (url.pathname === '/media/logo' || url.pathname === '/media/background') {
      if (!env.MEDIA) return new Response('Media storage is not configured', { status: 503 });
      try {
        const kind = url.pathname.endsWith('/logo') ? 'logo' : 'background';
        const key = await env.DB.prepare('SELECT value FROM settings WHERE key=?').bind(kind + '_key').first();
        if (!key?.value) return new Response('Not found', { status: 404 });
        const obj = await env.MEDIA.get(key.value);
        if (!obj) return new Response('Not found', { status: 404 });
        const h = new Headers(); obj.writeHttpMetadata(h); h.set('cache-control', 'public, max-age=300');
        return new Response(obj.body, { headers: h });
      } catch (e) { return new Response('Media unavailable', { status: 404 }); }
    }
    if (url.pathname.startsWith('/api/')) {
      if (!['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'].includes(request.method)) return json({ error: 'Method not allowed' }, 405);
      if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: { 'access-control-allow-origin': url.origin, 'access-control-allow-credentials': 'true', 'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS', 'access-control-allow-headers': 'Content-Type' } });
      try { return await api(request, env); }
      catch (error) { console.error('XgenCloud API error:', error); return json({ error: 'Server error. Please try again.' }, 500); }
    }
    // The admin dashboard lives only on the separate admin Worker.
    if (url.pathname === '/admin' || url.pathname === '/admin.html' || url.pathname === '/admin.js' || url.pathname === '/admin.css') {
      return Response.redirect(ADMIN_ORIGIN + '/', 302);
    }
    // Each category has its own page: /category/<id> serves the single-page app,
    // which renders that category from /api/config. Unknown ids get a friendly client-side notice.
    if (url.pathname === '/category' || url.pathname.startsWith('/category/')) {
      if (!['GET', 'HEAD'].includes(request.method)) return new Response('Method not allowed', { status: 405, headers: { allow: 'GET, HEAD' } });
      return env.ASSETS.fetch(new Request(new URL('/', url), request));
    }
    return env.ASSETS.fetch(request);
  }
};

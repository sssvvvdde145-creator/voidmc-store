const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const money=n=>"₹"+Number(n||0).toLocaleString("en-IN");
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(t){const el=$("#toast");el.textContent=t;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2300)}
function show(id){$("#"+id).classList.add("show")}function hide(id){$("#"+id).classList.remove("show")}
$$("[data-close]").forEach(b=>b.onclick=()=>hide(b.dataset.close));
$$(".overlay").forEach(o=>o.addEventListener("click",e=>{if(e.target===o)o.classList.remove("show")}));

let config=null,products={},categories=[],cart={},coupon="",discountPct=0,activeOrder=null;
const PERIOD_LABEL={monthly:"Monthly",quarterly:"Quarterly",yearly:"Yearly"};
const PERIOD_SUFFIX={monthly:"/mo",quarterly:"/qtr",yearly:"/yr"};
const CAT_ICONS=["🖥️","🎮","🌐","⚡","🛡️","📦","☁️","🚀"];

// ---------- Routing: / is the homepage, /category/<id> is one page per category ----------
const catMatch=location.pathname.match(/^\/category\/([^/]+)\/?$/);
const routeCatId=catMatch?decodeURIComponent(catMatch[1]):null;
const catUrl=c=>"/category/"+encodeURIComponent(c.id);

// ---------- Hamburger drawer ----------
const drawer=$("#drawer"),backdrop=$("#drawer-backdrop"),burger=$("#menu-open");
function openDrawer(){drawer.hidden=false;backdrop.hidden=false;requestAnimationFrame(()=>{drawer.classList.add("show");backdrop.classList.add("show")});burger.classList.add("open");burger.setAttribute("aria-expanded","true")}
function closeDrawer(){drawer.classList.remove("show");backdrop.classList.remove("show");burger.classList.remove("open");burger.setAttribute("aria-expanded","false");setTimeout(()=>{if(!drawer.classList.contains("show")){drawer.hidden=true;backdrop.hidden=true}},320)}
burger.onclick=()=>drawer.classList.contains("show")?closeDrawer():openDrawer();
$("#menu-close").onclick=closeDrawer;
backdrop.onclick=closeDrawer;
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&drawer.classList.contains("show"))closeDrawer()});
$("#drawer-cat-toggle").onclick=()=>{const t=$("#drawer-cat-toggle"),c=$("#drawer-cats"),open=!c.classList.contains("open");c.classList.toggle("open",open);t.classList.toggle("on",open);t.setAttribute("aria-expanded",String(open))};
$$("#drawer [data-nav]").forEach(a=>a.addEventListener("click",closeDrawer));

function renderDrawerCats(){
  const wrap=$("#drawer-cats"),mains=categories.filter(c=>!c.parentId);
  if(!mains.length){wrap.innerHTML='<p class="drawer-empty">Categories coming soon.</p>';return}
  wrap.innerHTML=mains.map(c=>{const subs=categories.filter(s=>s.parentId===c.id);
    return `<div class="drawer-cat"><div class="drawer-cat-row"><a class="drawer-cat-head${c.id===routeCatId?" current":""}" href="${esc(catUrl(c))}" data-nav-cat>${esc(c.name)}</a>${subs.length?`<button class="drawer-cat-expand" data-cat="${esc(c.id)}" aria-label="Show subcategories"><span class="chev">▾</span></button>`:""}</div>${subs.length?`<div class="drawer-subs" id="subs-${esc(c.id)}">${subs.map(s=>`<a class="drawer-sub" href="${esc(catUrl(c))}#cat-${esc(s.id)}" data-nav-cat>${esc(s.name)}</a>`).join("")}</div>`:""}</div>`}).join("");
  wrap.querySelectorAll("[data-cat]").forEach(b=>b.onclick=()=>{
    const subs=$("#subs-"+CSS.escape(b.dataset.cat));if(!subs)return;
    const open=!subs.classList.contains("open");
    subs.classList.toggle("open",open);b.classList.toggle("on",open);
  });
  wrap.querySelectorAll("[data-nav-cat]").forEach(a=>a.addEventListener("click",closeDrawer));
}

// ---------- Shop rendering ----------
function defaultPeriod(p){return ["monthly","quarterly","yearly"].find(k=>Number(p.prices[k])>0)||"monthly"}
function productCard(p,tierLabel){
  const dp=defaultPeriod(p),price=Number(p.prices[dp]);
  const alt=["monthly","quarterly","yearly"].filter(k=>k!==dp&&Number(p.prices[k])>0).map(k=>`${money(p.prices[k])}${PERIOD_SUFFIX[k]}`).join(" · ");
  const out=p.stock===0;
  const stockLine=p.stock===-1?"":out?'<p class="p-stock out">Out of stock</p>':p.stock<=5?`<p class="p-stock">Only ${p.stock} left</p>`:'<p class="p-stock">In stock</p>';
  const specs=(p.specs||[]).slice(0,5).map(s=>`<li>${esc(s)}</li>`).join("");
  return `<article class="product-card">
    ${p.imageUrl?`<img class="p-img" src="${esc(p.imageUrl)}" alt="${esc(p.name)}" loading="lazy">`:'<div class="p-icon">🖥️</div>'}
    ${tierLabel?`<p class="p-tier">${esc(tierLabel)}</p>`:""}
    <h4>${esc(p.name)}</h4>
    <div class="p-price">${money(price)}<small>${PERIOD_SUFFIX[dp]}</small></div>
    <p class="p-alt">${alt?esc(alt):"&nbsp;"}</p>
    ${p.description?`<p class="p-desc">${esc(p.description)}</p>`:""}
    ${specs?`<ul class="p-specs">${specs}</ul>`:""}
    ${stockLine}
    <button class="btn add" data-add="${esc(p.id)}" ${out?"disabled":""}>${out?"Out of stock":"Add to cart"}</button></article>`;
}
function catIcon(c,i){return c.imageUrl?`<img src="${esc(c.imageUrl)}" alt="${esc(c.name)}" loading="lazy">`:`<div class="cat-icon">${CAT_ICONS[i%CAT_ICONS.length]}</div>`}

// Homepage: one card per main category, each linking to that category's own page.
function renderHome(){
  const wrap=$("#category-cards"),mains=categories.filter(c=>!c.parentId);
  if(!mains.length){wrap.innerHTML='<p class="shop-empty">Hosting categories are being set up. Please check back soon, or join our Discord for updates.</p>';return}
  wrap.innerHTML=mains.map((c,i)=>{
    const subs=categories.filter(s=>s.parentId===c.id);
    const count=Object.values(products).filter(p=>p.categoryId===c.id||subs.some(s=>s.id===p.categoryId||s.id===p.subcategoryId)).length;
    return `<a class="cat-card" href="${esc(catUrl(c))}">${catIcon(c,i)}<h3>${esc(c.name)}</h3>${c.description?`<p>${esc(c.description)}</p>`:""}<span class="cat-meta">${count?count+" plan"+(count===1?"":"s"):"Plans coming soon"} · Browse →</span></a>`;
  }).join("");
}

// Category page: the category's own subcategories and products, nothing hardcoded.
function renderCategoryPage(){
  const view=$("#view-category"),detail=$("#category-detail");
  const c=categories.find(x=>x.id===routeCatId&&!x.parentId);
  if(!c){document.title="Category not found | XgenCloud";detail.innerHTML='<p class="shop-empty">This category does not exist or is no longer available. <a href="/#categories">Browse all hosting categories</a>.</p>';return}
  document.title=c.name+" | XgenCloud";
  const mains=categories.filter(x=>!x.parentId),i=mains.indexOf(c);
  const subs=categories.filter(s=>s.parentId===c.id);
  const prodsIn=id=>Object.values(products).filter(p=>p.categoryId===id||p.subcategoryId===id);
  const direct=Object.values(products).filter(p=>p.categoryId===c.id&&!p.subcategoryId);
  let inner="";
  if(direct.length)inner+=`<div class="product-grid">${direct.map(p=>productCard(p,c.name)).join("")}</div>`;
  for(const s of subs){
    const sp=prodsIn(s.id);
    inner+=`<div id="cat-${esc(s.id)}" class="sub-block"><p class="sub-head">${esc(s.name.toUpperCase())}</p>${sp.length?`<div class="product-grid">${sp.map(p=>productCard(p,s.name)).join("")}</div>`:'<p class="shop-empty">Plans coming soon.</p>'}</div>`;
  }
  if(!inner)inner='<p class="shop-empty">Plans coming soon.</p>';
  detail.innerHTML=`<div class="cat-head">${catIcon(c,i<0?0:i)}<h3>${esc(c.name)}</h3>${c.description?`<p>${esc(c.description)}</p>`:""}</div>${inner}`;
  if(location.hash){const t=document.getElementById(location.hash.slice(1));if(t)t.scrollIntoView()}
}

function renderRoute(){
  const home=$("#view-home"),view=$("#view-category");
  if(routeCatId){home.hidden=true;view.hidden=false;renderCategoryPage();bindAddButtons()}
  else{document.title="XgenCloud™ | Premium Hosting Store";view.hidden=true;home.hidden=false;renderHome()}
}
function bindAddButtons(){$$("#view-category [data-add]").forEach(b=>b.onclick=()=>{const p=products[b.dataset.add];if(!p)return;const key=p.id+":"+defaultPeriod(p);cart[key]=(cart[key]||0)+1;renderCart();toast(p.name+" added to cart")})}

// ---------- Cart ----------
function cartEntries(){return Object.entries(cart).map(([key,qty])=>{const[id,period]=key.split(":");return{key,id,period,qty,p:products[id]}}).filter(x=>x.p)}
function totals(){const sub=cartEntries().reduce((s,x)=>s+Number(x.p.prices[x.period])*x.qty,0);const disc=Math.floor(sub*discountPct/100);return{sub,discount:disc,total:sub-disc}}
function renderCart(){
  const entries=cartEntries();
  $("#cart-count").textContent=entries.reduce((s,x)=>s+x.qty,0);
  $("#cart-items").innerHTML=entries.length?entries.map(x=>{
    const periods=["monthly","quarterly","yearly"].filter(k=>Number(x.p.prices[k])>0);
    const opts=periods.map(k=>`<option value="${k}" ${k===x.period?"selected":""}>${PERIOD_LABEL[k]} - ${money(x.p.prices[k])}${PERIOD_SUFFIX[k]}</option>`).join("");
    return `<div class="cart-line"><div class="cl-info"><b>${esc(x.p.name)}</b><small>${money(x.p.prices[x.period])}${PERIOD_SUFFIX[x.period]} × ${x.qty} = ${money(Number(x.p.prices[x.period])*x.qty)}</small></div><div class="cl-side"><select data-period="${esc(x.key)}" aria-label="Billing period">${opts}</select><button class="qty" data-dec="${esc(x.key)}" aria-label="Decrease">−</button><button class="qty" data-inc="${esc(x.key)}" aria-label="Increase">+</button><button class="rm" data-remove="${esc(x.key)}">Remove</button></div></div>`;
  }).join(""):'<p class="muted">Your cart is empty. Choose a hosting plan to get started.</p>';
  $$("[data-remove]").forEach(b=>b.onclick=()=>{delete cart[b.dataset.remove];renderCart()});
  $$("[data-inc]").forEach(b=>b.onclick=()=>{if(cart[b.dataset.inc]<10)cart[b.dataset.inc]++;renderCart()});
  $$("[data-dec]").forEach(b=>b.onclick=()=>{cart[b.dataset.dec]--;if(cart[b.dataset.dec]<=0)delete cart[b.dataset.dec];renderCart()});
  $$("[data-period]").forEach(sel=>sel.onchange=()=>{const[id]=sel.dataset.period.split(":");const nk=id+":"+sel.value;cart[nk]=(cart[nk]||0)+cart[sel.dataset.period];delete cart[sel.dataset.period];renderCart()});
  const t=totals();
  $("#subtotal").textContent=money(t.sub);$("#discount").textContent="-"+money(t.discount);$("#total").textContent=money(t.total);
  $("#checkout-start").disabled=!entries.length;
}
$("#cart-open").onclick=()=>{renderCart();show("cart-modal")};
$("#apply-coupon").onclick=async()=>{const code=$("#coupon-input").value.trim().toUpperCase();if(!code)return toast("Enter a coupon code");try{const r=await fetch("/api/coupons/validate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code})});const d=await r.json();if(!r.ok)throw Error(d.error);coupon=code;discountPct=d.discount;$("#coupon-message").textContent=`${code} applied — ${d.discount}% off`;renderCart()}catch(e){coupon="";discountPct=0;$("#coupon-message").textContent=e.message;renderCart()}};
$("#checkout-start").onclick=()=>{if(!cartEntries().length)return;hide("cart-modal");show("checkout-modal")};

// ---------- Checkout / payment ----------
$("#checkout-form").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);
  const body={name:f.get("name"),location:f.get("location"),phone:f.get("phone"),username:f.get("username"),email:f.get("email"),coupon,items:cartEntries().map(x=>({productId:x.id,period:x.period,qty:x.qty}))};
  try{const r=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const d=await r.json();
    if(d.maintenance)applyMaintenance({enabled:true,message:d.message});
    if(!r.ok)throw Error(d.error);
    activeOrder={id:d.orderId,total:d.total};$("#purchase-prompt").textContent=d.prompt;$("#payment-total").textContent=money(d.total);
    hide("checkout-modal");show("prompt-modal");copyText(d.prompt,false);
    cart={};coupon="";discountPct=0;$("#coupon-input").value="";$("#coupon-message").textContent="";renderCart();
  }catch(err){toast(err.message)}};
async function copyText(text,notify=true){try{await navigator.clipboard.writeText(text);if(notify)toast("Copied to clipboard")}catch{const t=document.createElement("textarea");t.value=text;document.body.append(t);t.select();document.execCommand("copy");t.remove();if(notify)toast("Copied")}}
$("#copy-prompt").onclick=()=>copyText($("#purchase-prompt").textContent);
$("#already-copy").onclick=()=>{hide("prompt-modal");show("discord-modal")};
$("#show-payment").onclick=()=>{hide("discord-modal");show("payment-modal");fetch("/api/config").then(r=>r.json()).then(d=>{$("#upi-line").textContent=d.upiId?"UPI ID: "+d.upiId:"Use the payment QR code above.";if(d.paymentQrVersion)$("#payment-qr-img").src="/media/payment-qr?v="+encodeURIComponent(d.paymentQrVersion)})};
$("#paid-button").onclick=async()=>{if(!activeOrder)return;try{const r=await fetch(`/api/orders/${activeOrder.id}/paid`,{method:"POST"});const d=await r.json();if(!r.ok)throw Error(d.error);$("#code-result").hidden=false;$("#code-result").innerHTML=`<b>Payment submission code</b><code>${d.verificationCode}</code><button class="btn ghost" id="copy-code">Copy code</button><p class="muted">Give this code to an admin in your Discord Buy Item ticket. The code is not proof that funds have cleared.</p>`;$("#copy-code").onclick=()=>copyText(d.verificationCode);$("#paid-button").disabled=true;$("#paid-button").textContent="CODE GENERATED";}catch(e){toast(e.message)}};

// ---------- Config / branding / Discord ----------
function applyDiscord(url){if(!url)return;$$(".discord-cta").forEach(a=>a.href=url);const d=$("#drawer-discord");if(d)d.href=url}
async function loadConfig(){try{const d=await fetch("/api/config").then(r=>r.json());config=d;
  categories=(d.categories||[]).sort((a,b)=>a.sort-b.sort||a.name.localeCompare(b.name));
  products={};(d.products||[]).forEach(p=>products[p.id]=p);
  if(d.announcement){const bar=$("#announcement-bar");bar.hidden=false;$("#announcement-text").textContent=d.announcement;$("#announcement-copy").textContent=d.announcement}else $("#announcement-bar").hidden=true;
  if(d.logoUrl){["nav-logo","footer-logo"].forEach(id=>{const el=document.getElementById(id);if(el){el.src=d.logoUrl+"?v="+Date.now();el.hidden=false}})}
  if(d.backgroundUrl){document.body.classList.add("has-custom-bg");document.body.style.setProperty("--custom-bg",`url("${d.backgroundUrl}?v=${Date.now()}")`)}
  applyDiscord(d.discordInvite);
  renderDrawerCats();renderRoute();renderCart();
}catch(e){const target=routeCatId?$("#category-detail"):$("#category-cards");target.innerHTML='<p class="shop-empty" id="shop-loading">Could not load hosting plans. Please refresh to try again.</p>'}}

// ---------- Maintenance Mode: polled live from the database (no redeploy). The server also rejects orders while ON. ----------
let maintOn=false;
function applyMaintenance(m){const on=!!(m&&m.enabled),scr=$("#maintenance-screen");if(!scr)return;
  if(on){$("#maint-message").textContent=m.message||"We are performing scheduled maintenance. Please check back soon.";$$(".overlay.show").forEach(o=>o.classList.remove("show"));closeDrawer()}
  if(on===maintOn&&!on)return;const was=maintOn;maintOn=on;scr.hidden=!on;document.documentElement.classList.toggle("maint-lock",on);
  $$("body > :not(#maintenance-screen):not(script):not(#toast)").forEach(el=>{if(on)el.setAttribute("inert","");else el.removeAttribute("inert")});
  if(on&&!was)scr.querySelector(".maint-discord").focus({preventScroll:true})}
async function refreshMaintenance(){try{const r=await fetch("/api/maintenance",{cache:"no-store"});if(!r.ok)return;applyMaintenance(await r.json())}catch{}}
refreshMaintenance();setInterval(refreshMaintenance,15000);document.addEventListener("visibilitychange",()=>{if(!document.hidden)refreshMaintenance()});

// Refresh the active announcement periodically so admin edits appear without a site redeploy.
async function refreshAnnouncement(){try{const r=await fetch("/api/announcement",{cache:"no-store"});const d=await r.json();const bar=$("#announcement-bar");if(d.text){bar.hidden=false;$("#announcement-text").textContent=d.text;$("#announcement-copy").textContent=d.text}else bar.hidden=true}catch{}}
setInterval(refreshAnnouncement,60000);

if(routeCatId){$("#view-home").hidden=true;$("#view-category").hidden=false}
renderCart();loadConfig();

-- 0010: Seed the XgenCloud hosting catalogue (VPS, Bot, Web and Minecraft hosting)
-- exactly as provided by the store owner, plus the payment-QR settings rows.
-- Idempotent: fixed IDs + INSERT OR IGNORE, so re-running never duplicates or
-- overwrites anything. Everything seeded here can be edited or deleted afterwards
-- from the Admin Panel (Categories / Products tabs) — no code changes needed.

INSERT OR IGNORE INTO settings(key,value) VALUES ('payment_qr_key',''),('payment_qr_version','');

-- ============ CATEGORIES ============
-- Main categories
INSERT OR IGNORE INTO shop_categories (id,name,description,image_key,parent_id,enabled,sort,created_at,updated_at) VALUES
 ('CAT-VPS','VPS Hosting','Linux VPS with full root access, Docker support and Pterodactyl + Wings support. IPv4 options available.','','',1,10,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('CAT-BOT','Bot Hosting','Affordable bot hosting with shared memory and CPU, starting at Rs.5/month.','','',1,20,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('CAT-WEB','Web Hosting','Fast, secure and reliable web hosting. Every plan includes a control panel, PHP & MySQL support, free SSL certificates and customer support.','','',1,30,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('CAT-MC','Minecraft Hosting','Lowest price, high performance Minecraft server hosting.','','',1,40,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z');

-- Subcategories
INSERT OR IGNORE INTO shop_categories (id,name,description,image_key,parent_id,enabled,sort,created_at,updated_at) VALUES
 ('SUB-VPS-PLANS','VPS Plans','Monthly VPS plans with RAM, disk and vCore to fit every project.','','CAT-VPS',1,10,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('SUB-VPS-IPV4','IPv4 Add-ons','Added separately to your VPS plan.','','CAT-VPS',1,20,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('SUB-MC-BUDGET','Budget Plans','Lowest price Minecraft plans.','','CAT-MC',1,10,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('SUB-MC-PERF','Performance Plans','High performance Minecraft plans.','','CAT-MC',1,20,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z');

-- ============ VPS HOSTING — VPS PLANS ============
INSERT OR IGNORE INTO shop_products (id,name,description,specs,price_monthly,price_quarterly,price_yearly,image_key,category_id,subcategory_id,stock,enabled,featured,sort,created_at,updated_at) VALUES
 ('PRD-VPS-01','VPS 1 GB','Linux VPS with full root access, Docker support and Pterodactyl + Wings support.','1 GB RAM
5 GB Disk
1 vCore',25,0,0,'','CAT-VPS','SUB-VPS-PLANS',-1,1,0,10,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-VPS-02','VPS 2 GB','Linux VPS with full root access, Docker support and Pterodactyl + Wings support.','2 GB RAM
10 GB Disk
1 vCore',35,0,0,'','CAT-VPS','SUB-VPS-PLANS',-1,1,0,20,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-VPS-03','VPS 4 GB','Linux VPS with full root access, Docker support and Pterodactyl + Wings support.','4 GB RAM
20 GB Disk
1 vCore',55,0,0,'','CAT-VPS','SUB-VPS-PLANS',-1,1,0,30,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-VPS-04','VPS 6 GB','Linux VPS with full root access, Docker support and Pterodactyl + Wings support.','6 GB RAM
30 GB Disk
1 vCore',75,0,0,'','CAT-VPS','SUB-VPS-PLANS',-1,1,0,40,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-VPS-05','VPS 8 GB','Linux VPS with full root access, Docker support and Pterodactyl + Wings support.','8 GB RAM
40 GB Disk
2 vCore',95,0,0,'','CAT-VPS','SUB-VPS-PLANS',-1,1,0,50,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-VPS-06','VPS 12 GB','Linux VPS with full root access, Docker support and Pterodactyl + Wings support.','12 GB RAM
50 GB Disk
3 vCore',135,0,0,'','CAT-VPS','SUB-VPS-PLANS',-1,1,0,60,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-VPS-07','VPS 16 GB','Linux VPS with full root access, Docker support and Pterodactyl + Wings support.','16 GB RAM
75 GB Disk
4 vCore',175,0,0,'','CAT-VPS','SUB-VPS-PLANS',-1,1,0,70,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-VPS-08','VPS 24 GB','Linux VPS with full root access, Docker support and Pterodactyl + Wings support.','24 GB RAM
90 GB Disk
4 vCore',255,0,0,'','CAT-VPS','SUB-VPS-PLANS',-1,1,0,80,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-VPS-09','VPS 32 GB','Linux VPS with full root access, Docker support and Pterodactyl + Wings support.','32 GB RAM
150 GB Disk
6 vCore',335,0,0,'','CAT-VPS','SUB-VPS-PLANS',-1,1,0,90,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-VPS-10','VPS 40 GB','Linux VPS with full root access, Docker support and Pterodactyl + Wings support.','40 GB RAM
200 GB Disk
8 vCore',415,0,0,'','CAT-VPS','SUB-VPS-PLANS',-1,1,0,100,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z');

-- ============ VPS HOSTING — IPv4 ADD-ONS ============
INSERT OR IGNORE INTO shop_products (id,name,description,specs,price_monthly,price_quarterly,price_yearly,image_key,category_id,subcategory_id,stock,enabled,featured,sort,created_at,updated_at) VALUES
 ('PRD-VPS-IPV4-SHARED','Shared IPv4','IPv4 add-on for your VPS plan. Added separately to your VPS plan.','Access using IP + forwarded ports
Port forwarding support
Minecraft compatible
Pterodactyl support',65,0,0,'','CAT-VPS','SUB-VPS-IPV4',-1,1,0,10,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-VPS-IPV4-DED','Dedicated Public IPv4','IPv4 add-on for your VPS plan. Added separately to your VPS plan.','Your own public IPv4 address
Direct internet accessibility
Websites, APIs and applications
Minecraft and game servers',265,0,0,'','CAT-VPS','SUB-VPS-IPV4',-1,1,0,20,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z');

-- ============ BOT HOSTING ============
INSERT OR IGNORE INTO shop_products (id,name,description,specs,price_monthly,price_quarterly,price_yearly,image_key,category_id,subcategory_id,stock,enabled,featured,sort,created_at,updated_at) VALUES
 ('PRD-BOT-01','Bot 360 MB','Affordable bot hosting.','360 MB Shared Memory
30% Shared CPU
1 GB Disk',5,0,0,'','CAT-BOT','',-1,1,0,10,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-BOT-02','Bot 512 MB','Affordable bot hosting.','512 MB Shared Memory
50% Shared CPU
1.5 GB Disk',10,0,0,'','CAT-BOT','',-1,1,0,20,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-BOT-03','Bot 768 MB','Affordable bot hosting.','768 MB Shared Memory
75% Shared CPU
2 GB Disk',20,0,0,'','CAT-BOT','',-1,1,0,30,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-BOT-04','Bot 1 GB','Affordable bot hosting.','1 GB Shared Memory
100% Shared CPU
2.5 GB Disk',40,0,0,'','CAT-BOT','',-1,1,0,40,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-BOT-05','Bot 1.5 GB','Affordable bot hosting.','1.5 GB Shared Memory
150% Shared CPU
3 GB Disk',60,0,0,'','CAT-BOT','',-1,1,0,50,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-BOT-06','Bot 2 GB','Affordable bot hosting.','2 GB Shared Memory
200% Shared CPU
3 GB Disk',70,0,0,'','CAT-BOT','',-1,1,0,60,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z');

-- ============ WEB HOSTING ============
INSERT OR IGNORE INTO shop_products (id,name,description,specs,price_monthly,price_quarterly,price_yearly,image_key,category_id,subcategory_id,stock,enabled,featured,sort,created_at,updated_at) VALUES
 ('PRD-WEB-CHEAP','Cheap Plan','Easy-to-use hosting control panel, website management, PHP & MySQL support, free SSL certificates, reliable infrastructure and customer support.','1 GB SSD Storage
1 Email Account
1 FTP Account
1 MySQL Database
Free SSL Certificate
High-Speed Performance',15,0,0,'','CAT-WEB','',-1,1,0,10,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-WEB-STARTER','Starter Hosting','Easy-to-use hosting control panel, website management, PHP & MySQL support, free SSL certificates, reliable infrastructure and customer support.','5 GB SSD Storage
5 Email Accounts
2 FTP Accounts
2 MySQL Databases
Free SSL Certificate
High-Speed Performance',25,0,0,'','CAT-WEB','',-1,1,0,20,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-WEB-BASIC','Basic Hosting','Easy-to-use hosting control panel, website management, PHP & MySQL support, free SSL certificates, reliable infrastructure and customer support.','10 GB SSD Storage
10 Email Accounts
5 FTP Accounts
5 MySQL Databases
Free SSL Certificate
High-Speed Performance',50,0,0,'','CAT-WEB','',-1,1,0,30,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-WEB-BUSINESS','Business Hosting','Easy-to-use hosting control panel, website management, PHP & MySQL support, free SSL certificates, reliable infrastructure and customer support.','25 GB SSD Storage
25 Email Accounts
15 FTP Accounts
15 MySQL Databases
Free SSL Certificate
High-Speed Performance',99,0,0,'','CAT-WEB','',-1,1,0,40,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-WEB-PREMIUM','Premium Hosting','Easy-to-use hosting control panel, website management, PHP & MySQL support, free SSL certificates, reliable infrastructure and customer support.','50 GB SSD Storage
Unlimited Email Accounts
Unlimited FTP Accounts
Unlimited MySQL Databases
Free SSL Certificate
High-Speed Performance',199,0,0,'','CAT-WEB','',-1,1,0,50,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z');

-- ============ MINECRAFT HOSTING — BUDGET PLANS ============
INSERT OR IGNORE INTO shop_products (id,name,description,specs,price_monthly,price_quarterly,price_yearly,image_key,category_id,subcategory_id,stock,enabled,featured,sort,created_at,updated_at) VALUES
 ('PRD-MC-1','Minecraft Plan 1','Lowest price Minecraft hosting.','2 GB RAM
100% CPU
10 GB SSD',20,0,0,'','CAT-MC','SUB-MC-BUDGET',-1,1,0,10,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-MC-2','Minecraft Plan 2','Lowest price Minecraft hosting.','4 GB RAM
150% CPU
20 GB SSD',40,0,0,'','CAT-MC','SUB-MC-BUDGET',-1,1,0,20,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-MC-3','Minecraft Plan 3','Lowest price Minecraft hosting.','6 GB RAM
200% CPU
30 GB SSD',100,0,0,'','CAT-MC','SUB-MC-BUDGET',-1,1,0,30,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-MC-4','Minecraft Plan 4','Lowest price Minecraft hosting.','8 GB RAM
300% CPU
40 GB SSD',150,0,0,'','CAT-MC','SUB-MC-BUDGET',-1,1,1,40,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z');

-- ============ MINECRAFT HOSTING — PERFORMANCE PLANS ============
INSERT OR IGNORE INTO shop_products (id,name,description,specs,price_monthly,price_quarterly,price_yearly,image_key,category_id,subcategory_id,stock,enabled,featured,sort,created_at,updated_at) VALUES
 ('PRD-MC-5','Minecraft Plan 5','High performance Minecraft hosting.','12 GB RAM
400% CPU
50 GB SSD',180,0,0,'','CAT-MC','SUB-MC-PERF',-1,1,0,50,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-MC-6','Minecraft Plan 6','High performance Minecraft hosting.','16 GB RAM
500% CPU
60 GB SSD',200,0,0,'','CAT-MC','SUB-MC-PERF',-1,1,0,60,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-MC-7','Minecraft Plan 7','High performance Minecraft hosting.','24 GB RAM
600% CPU
80 GB SSD',300,0,0,'','CAT-MC','SUB-MC-PERF',-1,1,0,70,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z'),
 ('PRD-MC-8','Minecraft Plan 8','High performance Minecraft hosting.','32 GB RAM
800% CPU
120 GB SSD',400,0,0,'','CAT-MC','SUB-MC-PERF',-1,1,0,80,'2026-11-21T00:00:00.000Z','2026-11-21T00:00:00.000Z');

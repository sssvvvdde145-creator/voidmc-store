-- 0009: XgenCloud hosting store upgrade.
-- Idempotent and data-safe: customer accounts, historical orders, payment records,
-- coupons, announcements, settings and free-rank claim history are all preserved.
-- Only the obsolete rank catalogue is removed (orders keep their own item snapshots).

-- Dynamic hosting categories (main categories and subcategories).
CREATE TABLE IF NOT EXISTS shop_categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  image_key TEXT NOT NULL DEFAULT '',
  parent_id TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_shop_categories_parent ON shop_categories(parent_id, sort);

-- Hosting products.
CREATE TABLE IF NOT EXISTS shop_products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  specs TEXT NOT NULL DEFAULT '',
  price_monthly INTEGER NOT NULL DEFAULT 0,
  price_quarterly INTEGER NOT NULL DEFAULT 0,
  price_yearly INTEGER NOT NULL DEFAULT 0,
  image_key TEXT NOT NULL DEFAULT '',
  category_id TEXT NOT NULL DEFAULT '',
  subcategory_id TEXT NOT NULL DEFAULT '',
  stock INTEGER NOT NULL DEFAULT -1,
  enabled INTEGER NOT NULL DEFAULT 1,
  featured INTEGER NOT NULL DEFAULT 0,
  sort INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_shop_products_category ON shop_products(category_id, subcategory_id, sort);

-- IP ban / unban records. One row per ban event; unbanning marks the row, so the
-- full ban/unban history is preserved. The latest row per IP is its current status.
CREATE TABLE IF NOT EXISTS ip_bans (
  id TEXT PRIMARY KEY,
  ip TEXT NOT NULL,
  reason TEXT NOT NULL DEFAULT '',
  banned_by TEXT NOT NULL DEFAULT 'admin',
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  unbanned_at TEXT NOT NULL DEFAULT '',
  unbanned_by TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_ip_bans_ip ON ip_bans(ip, created_at);
CREATE INDEX IF NOT EXISTS idx_ip_bans_status ON ip_bans(status);

-- Admin activity log (ban/unban and other admin actions).
CREATE TABLE IF NOT EXISTS admin_activity_log (
  id TEXT PRIMARY KEY,
  action TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '',
  actor TEXT NOT NULL DEFAULT 'admin',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_activity_created ON admin_activity_log(created_at);

-- Lightweight server-side rate limiting for public checkout endpoints.
CREATE TABLE IF NOT EXISTS rate_limits (
  key TEXT PRIMARY KEY,
  count INTEGER NOT NULL DEFAULT 0,
  window_start INTEGER NOT NULL
);

-- Store settings added by XgenCloud. The Discord invite is editable in Admin > Branding.
INSERT OR IGNORE INTO settings(key,value) VALUES ('discord_invite','https://discord.gg/kBHUk8FcB');

-- Remove the obsolete rank catalogue and old category list. Orders store their own
-- item snapshots, so historical orders, customer records and payment codes are unaffected.
DELETE FROM ranks;
DELETE FROM categories;
